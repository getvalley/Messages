package com.glassmessages

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.layer.CompositingStrategy as LayerCompositingStrategy
import androidx.compose.ui.graphics.rememberGraphicsLayer

/**
 * Cheap "progressive blur" for the top [heightPx] pixels: ONE blurred copy of the content
 * is cross-faded with the sharp content using a gradient (blurred 100% at the very top,
 * 0% at the bottom edge of the zone). The blur is clipped to the zone, so the GPU only
 * works on that small strip. Android 12+ for real blur; older versions just fade out.
 */
@Composable
fun Modifier.topProgressiveBlur(heightPx: Float, radiusPx: Float): Modifier {
    if (heightPx <= 1f) return this
    val sharpMask = Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = 0f, endY = heightPx)
    if (Build.VERSION.SDK_INT < 31) {
        return this
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(sharpMask, size = Size(size.width, heightPx), blendMode = BlendMode.DstIn)
            }
    }
    val blurMask = Brush.verticalGradient(listOf(Color.Black, Color.Transparent), startY = 0f, endY = heightPx)
    val layer = rememberGraphicsLayer()
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            val zone = Size(size.width, heightPx)
            // 1) sharp content, fading out towards the top
            drawContent()
            drawRect(sharpMask, size = zone, blendMode = BlendMode.DstIn)
            // 2) one blurred copy, fading out towards the bottom
            layer.compositingStrategy = LayerCompositingStrategy.Offscreen
            layer.renderEffect = BlurEffect(radiusPx, radiusPx, TileMode.Clamp)
            layer.record {
                this@drawWithContent.drawContent()
                drawRect(blurMask, size = zone, blendMode = BlendMode.DstIn)
            }
            clipRect(top = 0f, bottom = heightPx) { drawLayer(layer) }
        }
}
