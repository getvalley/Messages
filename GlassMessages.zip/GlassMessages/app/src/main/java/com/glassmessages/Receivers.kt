package com.glassmessages

import android.app.*
import android.content.*
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val addr = msgs.firstOrNull()?.originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val v = ContentValues().apply {
            put(Telephony.Sms.ADDRESS, addr)
            put(Telephony.Sms.BODY, body)
            put(Telephony.Sms.DATE, System.currentTimeMillis())
            put(Telephony.Sms.READ, 0)
        }
        c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)

        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("msgs", "Messages", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, "msgs")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(SmsRepo(c).nameFor(addr))
            .setContentText(body)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(addr.hashCode(), n)
    }
}

// Required by the default SMS role. MMS is not handled in this version.
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {}
}

class RespondService : Service() {
    override fun onBind(i: Intent?) = null
}
