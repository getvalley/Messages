package com.glassmessages

import java.io.ByteArrayOutputStream

/** One MIME part of an MMS. [cid] is stored without angle brackets. */
class MmsPart(val mime: String, val name: String?, val cid: String?, val data: ByteArray, val charset: String = "UTF-8")

class MmsNotification(val tid: String, val location: String, val from: String?)

class MmsRetrieved(val from: String?, val to: List<String>, val subject: String?, val parts: List<MmsPart>)

/**
 * Minimal MMS PDU reader/writer (OMA MMS 1.2 over WSP encoding).
 * Enough to read m-notification-ind / m-retrieve-conf and to build m-send-req.
 */
object MmsCodec {
    private val WK_TYPES = mapOf(
        0x02 to "text/html", 0x03 to "text/plain", 0x06 to "text/x-vcalendar", 0x07 to "text/x-vcard",
        0x1D to "image/gif", 0x1E to "image/jpeg", 0x1F to "image/tiff", 0x20 to "image/png", 0x21 to "image/vnd.wap.wbmp"
    )

    private fun u(b: ByteArray, i: Int) = b[i].toInt() and 0xFF

    private fun uintvar(b: ByteArray, start: Int): Pair<Int, Int> {
        var p = start; var v = 0
        while (p < b.size) {
            val x = u(b, p++)
            v = (v shl 7) or (x and 0x7F)
            if ((x and 0x80) == 0) break
        }
        return v to p
    }

    private fun text(b: ByteArray, start: Int, limit: Int = b.size): Pair<String, Int> {
        var s = start
        if (s < limit && u(b, s) == 0x7F) s++
        var e = s
        while (e < limit && b[e] != 0.toByte()) e++
        return String(b, s, e - s, Charsets.UTF_8) to minOf(e + 1, limit)
    }

    /** Index just past the value that starts at [p] (works for every header value type). */
    private fun skip(b: ByteArray, p: Int): Int {
        if (p >= b.size) return b.size
        val v = u(b, p)
        return when {
            v >= 0x80 -> p + 1
            v < 31 -> p + 1 + v
            v == 31 -> { val (len, np) = uintvar(b, p + 1); np + len }
            else -> text(b, p).second
        }
    }

    private fun encoded(b: ByteArray, p: Int, limit: Int = b.size): Pair<String, Int> {
        val v = u(b, p)
        if (v >= 32) return text(b, p, limit)
        val (len, start) = if (v == 31) uintvar(b, p + 1) else v to p + 1
        val end = minOf(start + len, limit)
        var s = start
        if (s < end) {
            val c = u(b, s)
            s += if (c >= 0x80) 1 else if (c in 1..30) 1 + c else 0
        }
        return text(b, s, end).first to end
    }

    private fun longInt(b: ByteArray, p: Int): Pair<Long, Int> {
        val n = u(b, p); var v = 0L
        for (k in 1..n) v = (v shl 8) or u(b, p + k).toLong()
        return v to p + 1 + n
    }

    private fun clean(s: String) = s.substringBefore("/TYPE=").trim()

    private class Hdr {
        var type = -1
        var tid: String? = null
        var loc: String? = null
        var from: String? = null
        var subject: String? = null
        val to = mutableListOf<String>()
        var body = -1
    }

    private fun headers(b: ByteArray): Hdr {
        val h = Hdr(); var p = 0
        try {
            while (p < b.size) {
                val f = u(b, p)
                if (f < 0x80) break
                p++
                if (p >= b.size) break
                when (f) {
                    0x8C -> { h.type = u(b, p); p++ }
                    0x98 -> { val r = text(b, p); h.tid = r.first; p = r.second }
                    0x83 -> { val r = text(b, p); h.loc = r.first; p = r.second }
                    0x89 -> {
                        val v = u(b, p)
                        if (v in 2..30 && u(b, p + 1) == 0x80) h.from = clean(encoded(b, p + 2, p + 1 + v).first)
                        p = skip(b, p)
                    }
                    0x97, 0x82 -> { val r = encoded(b, p); h.to += clean(r.first); p = r.second }
                    0x96 -> { val r = encoded(b, p); h.subject = r.first; p = r.second }
                    0x84 -> { h.body = skip(b, p); return h }   // Content-Type: body follows
                    else -> p = skip(b, p)
                }
            }
        } catch (_: Exception) { }
        return h
    }

    fun parseNotification(b: ByteArray): MmsNotification? {
        val h = headers(b)
        if (h.type != 0x82) return null
        return MmsNotification(h.tid ?: return null, h.loc ?: return null, h.from)
    }

    fun parseRetrieve(b: ByteArray): MmsRetrieved? {
        val h = headers(b)
        if (h.body < 0) return null
        val parts = try { parts(b, h.body) } catch (_: Exception) { emptyList() }
        return MmsRetrieved(h.from, h.to.filter { it.isNotEmpty() }, h.subject?.takeIf { it.isNotBlank() }, parts)
    }

    private fun parts(b: ByteArray, start: Int): List<MmsPart> {
        val out = ArrayList<MmsPart>()
        var (n, p) = uintvar(b, start)
        repeat(n) {
            if (p >= b.size) return@repeat
            val (hl, a) = uintvar(b, p)
            val (dl, c) = uintvar(b, a)
            val hEnd = c + hl
            val dEnd = minOf(hEnd + dl, b.size)
            var q = c
            var mime = "application/octet-stream"
            var charset = "UTF-8"
            var name: String? = null
            var cid: String? = null

            val v = u(b, q)
            when {
                v >= 0x80 -> { mime = WK_TYPES[v and 0x7F] ?: mime; q++ }
                v <= 31 -> {
                    val (len, s0) = if (v == 31) uintvar(b, q + 1) else v to q + 1
                    val end = s0 + len
                    var r = s0
                    val m = u(b, r)
                    if (m >= 0x80) { mime = WK_TYPES[m and 0x7F] ?: mime; r++ }
                    else { val t = text(b, r, end); mime = t.first; r = t.second }
                    while (r + 1 < end && u(b, r) == 0x81) {      // charset parameter
                        val cv = u(b, r + 1)
                        charset = when (cv) { 0xEA -> "UTF-8"; 0x84 -> "ISO-8859-1"; 0x83 -> "US-ASCII"; 0x02 -> "UTF-16"; else -> charset }
                        r += if (cv == 0x02) 4 else 2
                    }
                    q = end
                }
                else -> { val t = text(b, q); mime = t.first; q = t.second }
            }
            while (q < hEnd) {
                val f = u(b, q)
                if (f < 0x80) break
                q++
                when (f) {
                    0xC0 -> { val t = text(b, if (u(b, q) == 0x22) q + 1 else q); cid = t.first.trim('<', '>', '"'); q = t.second }
                    0x8E -> { val t = text(b, q); name = t.first; q = t.second }
                    else -> q = skip(b, q)
                }
            }
            out += MmsPart(mime.lowercase(), name, cid, b.copyOfRange(minOf(hEnd, b.size), dEnd), charset)
            p = dEnd
        }
        return out
    }

    // ---------------------------------------------------------------- compose

    private fun uintvarBytes(v: Int): ByteArray {
        val l = ArrayList<Byte>()
        var x = v ushr 7
        l.add((v and 0x7F).toByte())
        while (x > 0) { l.add(0, ((x and 0x7F) or 0x80).toByte()); x = x ushr 7 }
        return l.toByteArray()
    }

    private fun ByteArrayOutputStream.str(s: String) { write(s.toByteArray(Charsets.UTF_8)); write(0) }
    private fun ByteArrayOutputStream.valueLen(n: Int) { if (n < 31) write(n) else { write(31); write(uintvarBytes(n)) } }

    fun buildSendReq(tid: String, to: List<String>, parts: List<MmsPart>): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(0x8C); o.write(0x80)                 // m-send-req
        o.write(0x98); o.str(tid)
        o.write(0x8D); o.write(0x92)                 // MMS 1.2
        o.write(0x89); o.write(1); o.write(0x81)     // From: insert-address-token
        for (a in to) {
            val addr = if (a.contains("@")) a else a.filter { it.isDigit() || it == '+' } + "/TYPE=PLMN"
            o.write(0x97); o.str(addr)
        }
        o.write(0x8A); o.write(0x80)                 // class: personal
        o.write(0x8F); o.write(0x81)                 // priority: normal
        o.write(0x86); o.write(0x81)                 // delivery report: no
        o.write(0x90); o.write(0x81)                 // read report: no

        val ct = ByteArrayOutputStream()
        ct.write(0xB3)                               // application/vnd.wap.multipart.related
        ct.write(0x8A); ct.str("<smil>")             // start
        ct.write(0x89); ct.str("application/smil")   // type
        o.write(0x84); o.valueLen(ct.size()); o.write(ct.toByteArray())

        o.write(uintvarBytes(parts.size))
        for (p in parts) {
            val h = ByteArrayOutputStream()
            if (p.mime == "text/plain") {
                val inner = ByteArrayOutputStream()
                inner.str("text/plain"); inner.write(0x81); inner.write(0xEA)   // charset=UTF-8
                h.valueLen(inner.size()); h.write(inner.toByteArray())
            } else h.str(p.mime)
            p.cid?.let { h.write(0xC0); h.write(0x22); h.str("<$it>") }
            p.name?.let { h.write(0x8E); h.str(it) }
            o.write(uintvarBytes(h.size())); o.write(uintvarBytes(p.data.size))
            o.write(h.toByteArray()); o.write(p.data)
        }
        return o.toByteArray()
    }

    /** Builds the SMIL layout part most MMS gateways expect. */
    fun smil(parts: List<MmsPart>): MmsPart {
        val sb = StringBuilder("<smil><head><layout><root-layout width=\"320\" height=\"480\"/>" +
            "<region id=\"Image\" fit=\"meet\" top=\"0\" left=\"0\" height=\"80%\" width=\"100%\"/>" +
            "<region id=\"Text\" fit=\"meet\" top=\"80%\" left=\"0\" height=\"20%\" width=\"100%\"/></layout></head><body>")
        val media = parts.filter { !it.mime.startsWith("text/") && it.name != null }
        val texts = parts.filter { it.mime == "text/plain" }
        fun par(inner: String) { sb.append("<par dur=\"5000ms\">").append(inner).append("</par>") }
        if (media.isEmpty()) texts.forEach { par("<text src=\"${it.name}\" region=\"Text\"/>") }
        else media.forEachIndexed { i, m ->
            val tag = when {
                m.mime.startsWith("image/") -> "img"
                m.mime.startsWith("video/") -> "video"
                m.mime.startsWith("audio/") -> "audio"
                else -> "ref"
            }
            val region = if (tag == "audio") "" else " region=\"Image\""
            val extra = if (i == 0) texts.joinToString("") { "<text src=\"${it.name}\" region=\"Text\"/>" } else ""
            par("<$tag src=\"${m.name}\"$region/>$extra")
        }
        sb.append("</body></smil>")
        return MmsPart("application/smil", "smil.xml", "smil", sb.toString().toByteArray())
    }
}
