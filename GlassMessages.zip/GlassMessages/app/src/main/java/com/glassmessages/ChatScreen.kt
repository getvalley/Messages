package com.glassmessages

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme

@Composable
fun WallpaperLayer(w: Wallpaper) {
    val bg = MaterialTheme.colorScheme.background
    val img = remember(w.imagePath) {
        w.imagePath?.let { BitmapFactory.decodeFile(it, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap() }
    }
    Box(Modifier.fillMaxSize()) {
        if (img != null) {
            Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val p = Presets.firstOrNull { it.id == w.preset }
            Box(Modifier.fillMaxSize().background(if (p != null) Brush.verticalGradient(p.colors) else SolidColor(bg)))
        }
        if (w.dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = w.dim)))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(thread: ChatThread, repo: SmsRepo, wp: WallpaperStore, onBack: () -> Unit) {
    val msgs by remember(thread.id) { repo.messagesFlow(thread.id) }.collectAsState(emptyList())
    val listState = rememberLazyListState()
    var draft by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf(false) }
    val dark = isSystemInDarkTheme()
    val glass = if (dark) Color(0xCC1C1C1E) else Color(0xCCFFFFFF)

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex) }

    Box(Modifier.fillMaxSize()) {
        WallpaperLayer(wp.get(thread.id))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            // Header
            Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Box(Modifier.align(Alignment.CenterStart).size(40.dp).clip(CircleShape).background(glass).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBackIosNew, "Back", tint = IBlue, modifier = Modifier.size(18.dp))
                }
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(thread.name, 44)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.clip(RoundedCornerShape(50)).background(glass).clickable { sheet = true }.padding(horizontal = 12.dp, vertical = 3.dp)) {
                        Text(thread.name, fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Box(Modifier.align(Alignment.CenterEnd).size(40.dp).clip(CircleShape).background(glass).clickable { sheet = true },
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Wallpaper, "Wallpaper", tint = IBlue, modifier = Modifier.size(20.dp))
                }
            }

            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), state = listState) {
                itemsIndexed(msgs, key = { _, m -> m.id }) { i, m ->
                    val prev = msgs.getOrNull(i - 1); val next = msgs.getOrNull(i + 1)
                    if (prev == null || m.date - prev.date > 3_600_000L) {
                        Text(shortTime(m.date), fontSize = 12.sp, color = Color.Gray,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                    val lastInGroup = next == null || next.mine != m.mine || next.date - m.date > 3_600_000L
                    Bubble(m, lastInGroup, dark)
                }
            }

            // Input bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(glass), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, null, tint = Color.Gray)
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(glass)
                        .border(0.5.dp, Color.Gray.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                        .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                        if (draft.isEmpty()) Text("Text Message", color = Color.Gray, fontSize = 16.sp)
                        BasicTextField(
                            draft, { draft = it }, Modifier.fillMaxWidth(),
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                            cursorBrush = SolidColor(IBlue), maxLines = 5
                        )
                    }
                    if (draft.isNotBlank()) {
                        Box(Modifier.size(30.dp).clip(CircleShape).background(IBlue).clickable {
                            repo.send(thread.address, draft.trim()); draft = ""
                        }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.ArrowUpward, "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (sheet) WallpaperSheet(thread.id, wp) { sheet = false }
}

@Composable
fun Bubble(m: Msg, tail: Boolean, dark: Boolean) {
    val bg = when {
        m.mine -> IBlue
        dark -> Color(0xFF2C2C2E)
        else -> Color(0xFFE9E9EB)
    }
    val fg = if (m.mine || dark) Color.White else Color.Black
    val big = 19.dp; val small = 5.dp
    val shape = RoundedCornerShape(
        topStart = big, topEnd = big,
        bottomStart = if (!m.mine && tail) small else big,
        bottomEnd = if (m.mine && tail) small else big
    )
    Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = if (tail) 6.dp else 0.dp),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
        Box(Modifier.widthIn(max = 290.dp).clip(shape).background(bg).padding(horizontal = 13.dp, vertical = 8.dp)) {
            Text(m.body, color = fg, fontSize = 16.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperSheet(threadId: Long, wp: WallpaperStore, onDismiss: () -> Unit) {
    var forAll by remember { mutableStateOf(!wp.hasOverride(threadId)) }
    val key = if (forAll) "all" else wp.keyFor(threadId)
    val current = wp.get(threadId)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) wp.setImage(key, uri)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Chat wallpaper", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Use for all chats", Modifier.weight(1f))
                Switch(forAll, { forAll = it })
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.heightIn(max = 260.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(Presets) { p ->
                    Box(
                        Modifier.aspectRatio(0.62f).clip(RoundedCornerShape(14.dp))
                            .background(Brush.verticalGradient(p.colors))
                            .border(if (current.preset == p.id) 3.dp else 0.dp, IBlue, RoundedCornerShape(14.dp))
                            .clickable { wp.setPreset(key, p.id) },
                        contentAlignment = Alignment.BottomCenter
                    ) { Text(p.name, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(6.dp)) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Dim", fontSize = 14.sp, color = Color.Gray)
            Slider(current.dim, { wp.setDim(key, it) }, valueRange = 0f..0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Choose photo")
                }
                OutlinedButton(onClick = { wp.reset(key) }) { Text("Reset") }
            }
        }
    }
}
