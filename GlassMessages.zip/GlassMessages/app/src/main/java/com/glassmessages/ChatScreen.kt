@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)

package com.glassmessages

import android.app.NotificationManager
import android.graphics.BitmapFactory
import android.util.Patterns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.material.icons.automirrored.filled.Reply
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.isSystemInDarkTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun WallpaperLayer(w: Wallpaper) {
    val bg = MaterialTheme.colorScheme.background
    val img = remember(w.imagePath) {
        w.imagePath?.let { BitmapFactory.decodeFile(it, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap() }
    }
    Box(Modifier.fillMaxSize()) {
        if (img != null) {
            Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val p = Presets.firstOrNull { it.id == w.preset }
            Box(Modifier.fillMaxSize().background(if (p != null) Brush.verticalGradient(p.colors) else SolidColor(bg)))
        }
        if (w.dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = w.dim)))
    }
}

/** Average colour of the part of the photo that actually shows at the top of the screen (the wallpaper is drawn with Crop). */
private fun topColorOfImage(path: String, screenAspect: Float): Color? = try {
    val b = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 8 })
    if (b == null) null else {
        val visibleH = if (b.width.toFloat() / b.height < screenAspect) (b.width / screenAspect).toInt().coerceIn(1, b.height) else b.height
        val y0 = (b.height - visibleH) / 2
        val band = maxOf(1, visibleH / 10)
        var r = 0L; var g = 0L; var bl = 0L; var n = 0
        for (y in y0 until minOf(b.height, y0 + band)) for (x in 0 until b.width) {
            val p = b.getPixel(x, y)
            r += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; bl += p and 0xFF; n++
        }
        b.recycle()
        if (n == 0) null else Color((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
    }
} catch (_: Exception) { null }

/** The colour the chat background has at its very top (wallpaper photo, preset gradient or plain theme background, including dimming). */
@Composable
fun rememberWallpaperTopColor(w: Wallpaper): Color {
    val bg = MaterialTheme.colorScheme.background
    val cfg = LocalConfiguration.current
    val base = remember(w.imagePath, w.preset, bg, cfg.screenWidthDp, cfg.screenHeightDp) {
        w.imagePath?.let { topColorOfImage(it, cfg.screenWidthDp.toFloat() / cfg.screenHeightDp) }
            ?: Presets.firstOrNull { it.id == w.preset }?.colors?.firstOrNull()
            ?: bg
    }
    return if (w.dim > 0f) lerp(base, Color.Black, w.dim) else base
}

fun styledText(text: String, query: String, linkColor: Color): AnnotatedString = buildAnnotatedString {
    append(text)
    val m = Patterns.WEB_URL.matcher(text)
    while (m.find()) {
        val raw = m.group() ?: continue
        if (raw.contains("@") && !raw.contains("://")) continue
        val url = if (raw.contains("://")) raw else "https://$raw"
        addLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline))),
            m.start(), m.end())
    }
    if (query.isNotEmpty()) {
        var i = text.indexOf(query, 0, ignoreCase = true)
        while (i >= 0) {
            addStyle(SpanStyle(background = Color(0xFFFFE082), color = Color.Black), i, i + query.length)
            i = text.indexOf(query, i + query.length, ignoreCase = true)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(thread: ChatThread, repo: SmsRepo, wp: WallpaperStore, focusKey: String?, initialDraft: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val msgs by remember(thread.id) { repo.messagesFlow(thread) }.collectAsState(emptyList())
    val listState = rememberLazyListState()
    val drafts = remember { DraftStore(ctx) }
    var draft by remember(thread.id) { mutableStateOf(initialDraft.ifEmpty { drafts.get(thread.id) }) }
    fun setDraft(t: String) { draft = t; drafts.set(thread.id, t) }
    val pending = remember { mutableStateListOf<PendingAttachment>() }
    var sheet by remember { mutableStateOf(false) }
    var contactSheet by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var cursor by remember { mutableIntStateOf(0) }
    var flashKey by remember { mutableStateOf(focusKey) }
    var menu by remember { mutableStateOf<Msg?>(null) }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    val focus = remember { FocusRequester() }
    var viewing by remember { mutableStateOf<Attachment?>(null) }
    val dark = isSystemInDarkTheme()
    val glass = if (dark) Color(0xCC1C1C1E) else Color(0xCCFFFFFF)
    val density = LocalDensity.current
    var headerPx by remember { mutableFloatStateOf(0f) }
    val headerDp = with(density) { headerPx.toDp() }
    val wallpaper = wp.get(thread.id)
    val headerTop = rememberWallpaperTopColor(wallpaper)

    val q = if (searching) query.trim() else ""
    val matches = remember(msgs, q) { if (q.isEmpty()) emptyList() else msgs.indices.filter { msgs[it].body.contains(q, true) } }
    val cur = cursor.coerceIn(0, maxOf(0, matches.lastIndex))
    val currentKey = matches.getOrNull(cur)?.let { msgs[it].key }
    val lastMine = remember(msgs) { msgs.indexOfLast { it.mine } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(6)) { uris ->
        uris.forEach { pending.add(PendingAttachment(it, ctx.contentResolver.getType(it) ?: "image/jpeg")) }
    }

    DisposableEffect(thread.id) {
        AppState.openThread = thread.id
        ctx.getSystemService(NotificationManager::class.java).cancel(thread.id.toInt())
        onDispose { AppState.openThread = -1L }
    }
    // Mark as read when the chat opens, when new messages arrive while it is open, and whenever the app returns to the foreground
    val resumes = AppState.resumeTick.intValue
    LaunchedEffect(msgs.size, msgs.lastOrNull()?.key, resumes) { withContext(Dispatchers.IO) { repo.markRead(thread.id) } }

    var initialDone by remember(thread.id) { mutableStateOf(false) }
    LaunchedEffect(msgs.isNotEmpty()) {
        if (msgs.isNotEmpty() && !initialDone) {
            initialDone = true
            val idx = focusKey?.let { k -> msgs.indexOfFirst { it.key == k } } ?: -1
            listState.scrollToItem(if (idx >= 0) idx else msgs.lastIndex)
            if (idx >= 0) { delay(2000); flashKey = null }
        }
    }
    LaunchedEffect(msgs.lastOrNull()?.key) {
        if (initialDone && !searching && msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }
    LaunchedEffect(cur, matches) { if (matches.isNotEmpty()) listState.animateScrollToItem(matches[cur]) }

    val doSend = {
        val text = draft.trim(); val atts = pending.toList(); val quoted = replyTo
        if (text.isNotEmpty() || atts.isNotEmpty()) {
            setDraft(""); pending.clear(); replyTo = null
            scope.launch {
                val err = repo.send(thread.addresses, if (quoted != null) buildReplyBody(quoted, text) else text, atts)
                if (err != null) {
                    Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
                    setDraft(text); pending.addAll(atts); replyTo = quoted
                }
            }
        }
    }

    fun startReply(m: Msg) {
        replyTo = m
        scope.launch { delay(150); try { focus.requestFocus() } catch (_: Exception) { } }
    }

    fun react(m: Msg, emoji: String) {
        val remove = m.reactions.any { it.mine && it.emoji == emoji }
        scope.launch {
            val err = repo.send(thread.addresses, reactionText(m, emoji, remove), emptyList())
            if (err != null) Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
        }
    }

    fun jumpToQuote(from: Int, quote: String) {
        val idx = (from - 1 downTo 0).firstOrNull { quoteMatches(msgs[it], quote) } ?: return
        scope.launch {
            listState.animateScrollToItem(idx)
            flashKey = msgs[idx].key
            delay(1500)
            flashKey = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        WallpaperLayer(wallpaper)
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 10.dp), state = listState,
                    contentPadding = PaddingValues(top = headerDp)) {
                    itemsIndexed(msgs, key = { _, m -> m.key }) { i, m ->
                        val prev = msgs.getOrNull(i - 1); val next = msgs.getOrNull(i + 1)
                        val newGroup = prev == null || m.date - prev.date > 3_600_000L
                        if (newGroup) {
                            Text(dayLabel(m.date), fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.Gray,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                        val lastInGroup = next == null || next.mine != m.mine || next.date - m.date > 3_600_000L || next.sender != m.sender
                        val showSender = thread.isGroup && !m.mine && (newGroup || prev!!.mine || prev.sender != m.sender)
                        val status = when {
                            m.status == Status.FAILED -> "Not Delivered"
                            i == lastMine && m.status == Status.SENDING -> "Sending…"
                            i == lastMine && m.status == Status.DELIVERED -> "Delivered"
                            i == lastMine && m.status == Status.SENT -> "Sent"
                            else -> null
                        }
                        SwipeReply(onReply = { startReply(m) }) {
                        Bubble(m, lastInGroup, dark, if (showSender) m.sender?.let { repo.nameFor(it) } else null, q,
                            flash = m.key == flashKey || m.key == currentKey, status = status, repo = repo,
                            onLong = { menu = m }, onQuoteClick = { jumpToQuote(i, it) }, onAttachment = { a ->
                                if (a.mime.startsWith("image/")) viewing = a
                                else if (!repo.open(a)) Toast.makeText(ctx, "No app can open this", Toast.LENGTH_SHORT).show()
                            })
                        }
                    }
                }

                val showJump by remember { derivedStateOf { listState.canScrollForward && msgs.isNotEmpty() } }
                AnimatedVisibility(showJump, Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 10.dp),
                    enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(glass).border(0.5.dp, Color.Gray.copy(alpha = 0.4f), CircleShape)
                        .clickable { scope.launch { listState.animateScrollToItem(msgs.lastIndex) } }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.KeyboardArrowDown, "Jump to latest", tint = IBlue)
                    }
                }

                // Header: solid background colour at the very top, fading to fully transparent at the bottom
                Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().onSizeChanged { headerPx = it.height.toFloat() }
                    .background(Brush.verticalGradient(listOf(headerTop, headerTop.copy(alpha = 0f))))) {
                // Header
                Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Box(Modifier.align(Alignment.CenterStart).size(40.dp).clip(CircleShape).background(glass).clickable(onClick = onBack),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.ArrowBackIosNew, "Back", tint = IBlue, modifier = Modifier.size(18.dp))
                    }
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.clip(CircleShape).clickable { contactSheet = true }) { Avatar(thread.name, 44, thread.isGroup) }
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.widthIn(max = 180.dp).clip(RoundedCornerShape(50)).background(glass).clickable { sheet = true }
                            .padding(horizontal = 12.dp, vertical = 3.dp)) {
                            Text(thread.name, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    Row(Modifier.align(Alignment.CenterEnd), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(glass).clickable { searching = !searching; query = "" },
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Search, "Search", tint = IBlue, modifier = Modifier.size(20.dp))
                        }
                        Box(Modifier.size(40.dp).clip(CircleShape).background(glass).clickable { sheet = true }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Wallpaper, "Wallpaper", tint = IBlue, modifier = Modifier.size(20.dp))
                        }
                    }
                }

                if (searching) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp).clip(RoundedCornerShape(14.dp)).background(glass).padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) {
                            if (query.isEmpty()) Text("Search in conversation", color = Color.Gray, fontSize = 15.sp)
                            BasicTextField(query, { query = it; cursor = Int.MAX_VALUE }, Modifier.fillMaxWidth(), singleLine = true,
                                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp), cursorBrush = SolidColor(IBlue))
                        }
                        if (q.isNotEmpty()) Text(if (matches.isEmpty()) "0" else "${cur + 1}/${matches.size}", fontSize = 12.sp, color = Color.Gray)
                        IconButton(onClick = { cursor = (cur - 1).coerceAtLeast(0) }, enabled = matches.isNotEmpty(), modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.KeyboardArrowUp, "Older", tint = IBlue)
                        }
                        IconButton(onClick = { cursor = (cur + 1).coerceAtMost(matches.lastIndex) }, enabled = matches.isNotEmpty(), modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.KeyboardArrowDown, "Newer", tint = IBlue)
                        }
                        IconButton(onClick = { searching = false; query = "" }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, "Close search", tint = IBlue)
                        }
                    }
                }

                }
            }

            replyTo?.let { r ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp).clip(RoundedCornerShape(14.dp)).background(glass)
                        .padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(3.dp).height(30.dp).clip(RoundedCornerShape(2.dp)).background(IBlue))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        val who = if (r.mine) "yourself" else (r.sender?.let { repo.nameFor(it) } ?: thread.name)
                        Text("Replying to $who", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = IBlue, maxLines = 1)
                        Text(quoteText(r), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { replyTo = null }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, "Cancel reply", tint = Color.Gray, modifier = Modifier.size(18.dp))
                    }
                }
            }

            if (pending.isNotEmpty()) {
                LazyRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pending.toList()) { a ->
                        val bmp by produceState<ImageBitmap?>(null, a.uri) { value = withContext(Dispatchers.IO) { repo.pendingThumb(a) } }
                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(glass)) {
                            bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                                ?: Icon(Icons.Default.AttachFile, null, Modifier.align(Alignment.Center), tint = Color.Gray)
                            Box(Modifier.align(Alignment.TopEnd).padding(3.dp).size(20.dp).clip(CircleShape).background(Color(0xAA000000))
                                .clickable { pending.remove(a) }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Close, "Remove", tint = Color.White, modifier = Modifier.size(13.dp))
                            }
                        }
                    }
                }
            }

            // Input bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(glass).clickable {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, "Attach", tint = Color.Gray)
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(glass)
                        .border(0.5.dp, Color.Gray.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                        .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                        if (draft.isEmpty()) Text(if (thread.isGroup || pending.isNotEmpty()) "MMS Message" else "Text Message", color = Color.Gray, fontSize = 16.sp)
                        BasicTextField(
                            draft, { setDraft(it) }, Modifier.fillMaxWidth().focusRequester(focus),
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                            cursorBrush = SolidColor(IBlue), maxLines = 5
                        )
                    }
                    if (draft.isNotBlank() || pending.isNotEmpty()) {
                        Box(Modifier.size(30.dp).clip(CircleShape).background(IBlue).clickable { doSend() }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.ArrowUpward, "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (sheet) WallpaperSheet(thread.id, wp) { sheet = false }
    if (contactSheet) ContactSheet(thread, repo) { contactSheet = false }
    viewing?.let { ImageViewer(it, repo) { viewing = null } }

    menu?.let { m ->
        MessageSheet(
            m, canCopy = plainBody(m).isNotEmpty(), canResend = m.status == Status.FAILED && !m.isMms && m.body.isNotEmpty(),
            onReact = { e -> react(m, e); menu = null },
            onReply = { startReply(m); menu = null },
            onCopy = { clipboard.setText(AnnotatedString(plainBody(m))); menu = null },
            onResend = { if (repo.delete(m)) repo.sendSms(thread.addresses.first(), m.body); menu = null },
            onDelete = {
                if (!repo.delete(m)) Toast.makeText(ctx,
                    if (repo.isDefault()) "Couldn't delete the message" else "Make Glass Messages your default SMS app to delete", Toast.LENGTH_SHORT).show()
                menu = null
            },
            onDismiss = { menu = null }
        )
    }
}

/** Drag a message to the right to reply to it. */
@Composable
fun SwipeReply(onReply: () -> Unit, content: @Composable () -> Unit) {
    val x = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val trigger = with(LocalDensity.current) { 56.dp.toPx() }
    val reply by rememberUpdatedState(onReply)
    Box(Modifier.fillMaxWidth().pointerInput(Unit) {
        var fired = false
        detectHorizontalDragGestures(
            onDragStart = { fired = false },
            onDragEnd = { scope.launch { x.animateTo(0f) } },
            onDragCancel = { scope.launch { x.animateTo(0f) } }
        ) { change, dx ->
            change.consume()
            val n = (x.value + dx * 0.5f).coerceIn(0f, trigger * 1.3f)
            scope.launch { x.snapTo(n) }
            if (!fired && n >= trigger) { fired = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress); reply() }
        }
    }) {
        if (x.value > 8f) Icon(Icons.AutoMirrored.Filled.Reply, null, tint = IBlue.copy(alpha = (x.value / trigger).coerceIn(0f, 1f)),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 6.dp).size(22.dp))
        Box(Modifier.offset { IntOffset(x.value.roundToInt(), 0) }) { content() }
    }
}

@Composable
fun Bubble(
    m: Msg, tail: Boolean, dark: Boolean, senderName: String?, query: String, flash: Boolean,
    status: String?, repo: SmsRepo, onLong: () -> Unit, onQuoteClick: (String) -> Unit, onAttachment: (Attachment) -> Unit
) {
    val bg = when {
        m.mine -> IBlue
        dark -> Color(0xFF2C2C2E)
        else -> Color(0xFFE9E9EB)
    }
    val fg = if (m.mine || dark) Color.White else Color.Black
    val big = 19.dp; val small = 5.dp
    val shape = RoundedCornerShape(
        topStart = big, topEnd = big,
        bottomStart = if (!m.mine && tail) small else big,
        bottomEnd = if (m.mine && tail) small else big
    )
    val (quote, shown) = remember(m.body) { splitReply(m.body) }
    val hasText = shown.isNotBlank() || quote != null || !m.subject.isNullOrBlank()
    Column(
        Modifier.fillMaxWidth().padding(top = 2.dp, bottom = if (tail && status == null) 6.dp else 0.dp),
        horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start
    ) {
        if (senderName != null) Text(senderName, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(start = 12.dp, bottom = 2.dp))
        m.attachments.forEach { a ->
            AttachmentView(a, repo, flash, onLong) { onAttachment(a) }
            Spacer(Modifier.height(2.dp))
        }
        if (hasText) {
            Box(
                Modifier.widthIn(max = 290.dp).clip(shape)
                    .then(if (m.mine) Modifier.background(Brush.verticalGradient(listOf(Color(0xFF3AA6FF), IBlue))) else Modifier.background(bg))
                    .then(if (flash) Modifier.border(2.dp, Color(0xFFFFC107), shape) else Modifier)
                    .combinedClickable(onClick = {}, onLongClick = onLong)
                    .padding(horizontal = 13.dp, vertical = 8.dp)
            ) {
                Column {
                    if (quote != null) {
                        Row(Modifier.padding(bottom = if (shown.isNotBlank()) 6.dp else 0.dp).height(IntrinsicSize.Min)
                            .clip(RoundedCornerShape(6.dp)).clickable { onQuoteClick(quote) }) {
                            Box(Modifier.width(3.dp).fillMaxHeight().background(fg.copy(alpha = 0.55f)))
                            Text(quote, color = fg.copy(alpha = 0.8f), fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                    if (!m.subject.isNullOrBlank()) Text(m.subject, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (shown.isNotBlank()) Text(styledText(shown, query, if (m.mine) Color.White else IBlue), color = fg, fontSize = 16.sp)
                }
            }
        }
        if (m.reactions.isNotEmpty()) {
            val counts = m.reactions.groupingBy { it.emoji }.eachCount()
            val label = counts.entries.joinToString("  ") { (e, n) -> if (n > 1) "$e $n" else e }
            val pill = if (dark) Color(0xFF3A3A3C) else Color.White
            Text(label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 10.dp).offset(y = (-6).dp)
                    .clip(RoundedCornerShape(50)).background(pill)
                    .border(0.5.dp, Color.Gray.copy(alpha = 0.4f), RoundedCornerShape(50))
                    .padding(horizontal = 8.dp, vertical = 2.dp))
        }
        if (status != null) Text(status, fontSize = 11.sp, color = if (status == "Not Delivered") Color.Red else Color.Gray,
            modifier = Modifier.padding(top = 2.dp, end = 4.dp, bottom = 6.dp))
    }
}

@Composable
fun AttachmentView(a: Attachment, repo: SmsRepo, flash: Boolean, onLong: () -> Unit, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val visual = a.mime.startsWith("image/") || a.mime.startsWith("video/")
    val base = Modifier.clip(shape)
        .then(if (flash) Modifier.border(2.dp, Color(0xFFFFC107), shape) else Modifier)
        .combinedClickable(onClick = onClick, onLongClick = onLong)
    if (visual) {
        val bmp by produceState<ImageBitmap?>(null, a.partId) { value = withContext(Dispatchers.IO) { repo.thumb(a) } }
        Box(base, contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(b, null, Modifier.widthIn(max = 240.dp).heightIn(max = 320.dp), contentScale = ContentScale.Fit)
            else Box(Modifier.size(width = 200.dp, height = 150.dp).background(Color.Gray.copy(alpha = 0.3f)))
            if (a.mime.startsWith("video/")) Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    } else {
        Row(base.background(Color.Gray.copy(alpha = 0.25f)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AttachFile, null, tint = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.width(8.dp))
            Text(a.name ?: a.mime, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 200.dp),
                color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun ImageViewer(att: Attachment, repo: SmsRepo, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, att.partId) { value = withContext(Dispatchers.IO) { repo.load(att, 2048) } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onClose)) {
            bmp?.let { Image(it, null, Modifier.fillMaxSize().systemBarsPadding(), contentScale = ContentScale.Fit) }
            Row(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) {
                IconButton(onClick = { if (!repo.share(att)) Toast.makeText(ctx, "Couldn't share", Toast.LENGTH_SHORT).show() }) {
                    Icon(Icons.Default.Share, "Share", tint = Color.White)
                }
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperSheet(threadId: Long, wp: WallpaperStore, onDismiss: () -> Unit) {
    var forAll by remember { mutableStateOf(!wp.hasOverride(threadId)) }
    val key = if (forAll) "all" else wp.keyFor(threadId)
    val current = wp.get(threadId)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) wp.setImage(key, uri)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Chat wallpaper", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Use for all chats", Modifier.weight(1f))
                Switch(forAll, { forAll = it })
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.heightIn(max = 260.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(Presets) { p ->
                    Box(
                        Modifier.aspectRatio(0.62f).clip(RoundedCornerShape(14.dp))
                            .background(Brush.verticalGradient(p.colors))
                            .border(if (current.preset == p.id) 3.dp else 0.dp, IBlue, RoundedCornerShape(14.dp))
                            .clickable { wp.setPreset(key, p.id) },
                        contentAlignment = Alignment.BottomCenter
                    ) { Text(p.name, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(6.dp)) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Dim", fontSize = 14.sp, color = Color.Gray)
            Slider(current.dim, { wp.setDim(key, it) }, valueRange = 0f..0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Choose photo")
                }
                OutlinedButton(onClick = { wp.reset(key) }) { Text("Reset") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactSheet(thread: ChatThread, repo: SmsRepo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text(if (thread.isGroup) "People" else "Contact", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            thread.addresses.forEach { a ->
                val saved = remember(a) { repo.contactUri(a) != null }
                val name = repo.nameFor(a)
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(name, 44)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (name != a) Text(a, fontSize = 13.sp, color = Color.Gray)
                    }
                    TextButton(onClick = { if (!repo.dial(a)) Toast.makeText(ctx, "Can't open dialer", Toast.LENGTH_SHORT).show() }) { Text("Call") }
                    Button(onClick = {
                        if (!repo.editContact(a)) Toast.makeText(ctx, "No contacts app found", Toast.LENGTH_SHORT).show() else onDismiss()
                    }) { Text(if (saved) "Edit" else "Add") }
                }
            }
        }
    }
}

@Composable
private fun SheetAction(icon: ImageVector, label: String, destructive: Boolean = false, onClick: () -> Unit) {
    val tint = if (destructive) Color(0xFFFF453A) else MaterialTheme.colorScheme.onSurface
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (destructive) tint else IBlue, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = tint, fontSize = 16.sp)
    }
}

/** Long-press menu for a message: reaction bar on top, then actions. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MessageSheet(
    m: Msg, canCopy: Boolean, canResend: Boolean,
    onReact: (String) -> Unit, onReply: () -> Unit, onCopy: () -> Unit, onResend: () -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit
) {
    val mine = m.reactions.firstOrNull { it.mine }?.emoji
    var more by remember(m.key) { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Text(shortTime(m.date) + if (m.isMms) " · MMS" else "", fontSize = 13.sp, color = Color.Gray,
                modifier = Modifier.padding(start = 4.dp, bottom = 10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Color.Gray.copy(alpha = 0.14f)).padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                QuickReactions.forEach { e ->
                    Box(Modifier.size(42.dp).clip(CircleShape).background(if (e == mine) IBlue.copy(alpha = 0.3f) else Color.Transparent)
                        .clickable { onReact(e) }, contentAlignment = Alignment.Center) { Text(e, fontSize = 23.sp) }
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(if (more) IBlue.copy(alpha = 0.3f) else Color.Transparent)
                    .clickable { more = !more }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, "More emojis", tint = IBlue, modifier = Modifier.size(22.dp))
                }
            }
            if (more) FlowRow(Modifier.fillMaxWidth().heightIn(max = 190.dp).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                MoreReactions.forEach { e ->
                    Box(Modifier.size(44.dp).clip(CircleShape).background(if (e == mine) IBlue.copy(alpha = 0.3f) else Color.Transparent)
                        .clickable { onReact(e) }, contentAlignment = Alignment.Center) { Text(e, fontSize = 23.sp) }
                }
            }
            Spacer(Modifier.height(10.dp))
            SheetAction(Icons.AutoMirrored.Filled.Reply, "Reply", onClick = onReply)
            if (canCopy) SheetAction(Icons.Default.ContentCopy, "Copy text", onClick = onCopy)
            if (canResend) SheetAction(Icons.Default.Refresh, "Resend", onClick = onResend)
            SheetAction(Icons.Default.Delete, "Delete", destructive = true, onClick = onDelete)
        }
    }
}
