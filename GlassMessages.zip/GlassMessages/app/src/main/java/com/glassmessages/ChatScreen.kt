@file:OptIn(ExperimentalFoundationApi::class)

package com.glassmessages

import android.app.NotificationManager
import android.graphics.BitmapFactory
import android.util.Patterns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.isSystemInDarkTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun WallpaperLayer(w: Wallpaper) {
    val bg = MaterialTheme.colorScheme.background
    val img = remember(w.imagePath) {
        w.imagePath?.let { BitmapFactory.decodeFile(it, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap() }
    }
    Box(Modifier.fillMaxSize()) {
        if (img != null) {
            Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val p = Presets.firstOrNull { it.id == w.preset }
            Box(Modifier.fillMaxSize().background(if (p != null) Brush.verticalGradient(p.colors) else SolidColor(bg)))
        }
        if (w.dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = w.dim)))
    }
}

fun styledText(text: String, query: String, linkColor: Color): AnnotatedString = buildAnnotatedString {
    append(text)
    val m = Patterns.WEB_URL.matcher(text)
    while (m.find()) {
        val raw = m.group() ?: continue
        if (raw.contains("@") && !raw.contains("://")) continue
        val url = if (raw.contains("://")) raw else "https://$raw"
        addLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline))),
            m.start(), m.end())
    }
    if (query.isNotEmpty()) {
        var i = text.indexOf(query, 0, ignoreCase = true)
        while (i >= 0) {
            addStyle(SpanStyle(background = Color(0xFFFFE082), color = Color.Black), i, i + query.length)
            i = text.indexOf(query, i + query.length, ignoreCase = true)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(thread: ChatThread, repo: SmsRepo, wp: WallpaperStore, focusKey: String?, initialDraft: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val msgs by remember(thread.id) { repo.messagesFlow(thread) }.collectAsState(emptyList())
    val listState = rememberLazyListState()
    var draft by remember { mutableStateOf(initialDraft) }
    val pending = remember { mutableStateListOf<PendingAttachment>() }
    var sheet by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var cursor by remember { mutableIntStateOf(0) }
    var flashKey by remember { mutableStateOf(focusKey) }
    var menu by remember { mutableStateOf<Msg?>(null) }
    var viewing by remember { mutableStateOf<Attachment?>(null) }
    val dark = isSystemInDarkTheme()
    val glass = if (dark) Color(0xCC1C1C1E) else Color(0xCCFFFFFF)

    val q = if (searching) query.trim() else ""
    val matches = remember(msgs, q) { if (q.isEmpty()) emptyList() else msgs.indices.filter { msgs[it].body.contains(q, true) } }
    val cur = cursor.coerceIn(0, maxOf(0, matches.lastIndex))
    val currentKey = matches.getOrNull(cur)?.let { msgs[it].key }
    val lastMine = remember(msgs) { msgs.indexOfLast { it.mine } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(6)) { uris ->
        uris.forEach { pending.add(PendingAttachment(it, ctx.contentResolver.getType(it) ?: "image/jpeg")) }
    }

    DisposableEffect(thread.id) {
        AppState.openThread = thread.id
        ctx.getSystemService(NotificationManager::class.java).cancel(thread.id.toInt())
        onDispose { AppState.openThread = -1L }
    }
    LaunchedEffect(msgs.size) { withContext(Dispatchers.IO) { repo.markRead(thread.id) } }

    var initialDone by remember(thread.id) { mutableStateOf(false) }
    LaunchedEffect(msgs.isNotEmpty()) {
        if (msgs.isNotEmpty() && !initialDone) {
            initialDone = true
            val idx = focusKey?.let { k -> msgs.indexOfFirst { it.key == k } } ?: -1
            listState.scrollToItem(if (idx >= 0) idx else msgs.lastIndex)
            if (idx >= 0) { delay(2000); flashKey = null }
        }
    }
    LaunchedEffect(msgs.lastOrNull()?.key) {
        if (initialDone && !searching && msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }
    LaunchedEffect(cur, matches) { if (matches.isNotEmpty()) listState.animateScrollToItem(matches[cur]) }

    val doSend = {
        val text = draft.trim(); val atts = pending.toList()
        if (text.isNotEmpty() || atts.isNotEmpty()) {
            draft = ""; pending.clear()
            scope.launch {
                val err = repo.send(thread.addresses, text, atts)
                if (err != null) {
                    Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
                    draft = text; pending.addAll(atts)
                }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        WallpaperLayer(wp.get(thread.id))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            // Header
            Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Box(Modifier.align(Alignment.CenterStart).size(40.dp).clip(CircleShape).background(glass).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ArrowBackIosNew, "Back", tint = IBlue, modifier = Modifier.size(18.dp))
                }
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(thread.name, 44, thread.isGroup)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.widthIn(max = 180.dp).clip(RoundedCornerShape(50)).background(glass).clickable { sheet = true }
                        .padding(horizontal = 12.dp, vertical = 3.dp)) {
                        Text(thread.name, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Row(Modifier.align(Alignment.CenterEnd), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(glass).clickable { searching = !searching; query = "" },
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Search, "Search", tint = IBlue, modifier = Modifier.size(20.dp))
                    }
                    Box(Modifier.size(40.dp).clip(CircleShape).background(glass).clickable { sheet = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Wallpaper, "Wallpaper", tint = IBlue, modifier = Modifier.size(20.dp))
                    }
                }
            }

            if (searching) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp).clip(RoundedCornerShape(14.dp)).background(glass).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Search in conversation", color = Color.Gray, fontSize = 15.sp)
                        BasicTextField(query, { query = it; cursor = Int.MAX_VALUE }, Modifier.fillMaxWidth(), singleLine = true,
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp), cursorBrush = SolidColor(IBlue))
                    }
                    if (q.isNotEmpty()) Text(if (matches.isEmpty()) "0" else "${cur + 1}/${matches.size}", fontSize = 12.sp, color = Color.Gray)
                    IconButton(onClick = { cursor = (cur - 1).coerceAtLeast(0) }, enabled = matches.isNotEmpty(), modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.KeyboardArrowUp, "Older", tint = IBlue)
                    }
                    IconButton(onClick = { cursor = (cur + 1).coerceAtMost(matches.lastIndex) }, enabled = matches.isNotEmpty(), modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.KeyboardArrowDown, "Newer", tint = IBlue)
                    }
                    IconButton(onClick = { searching = false; query = "" }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, "Close search", tint = IBlue)
                    }
                }
            }

            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), state = listState) {
                itemsIndexed(msgs, key = { _, m -> m.key }) { i, m ->
                    val prev = msgs.getOrNull(i - 1); val next = msgs.getOrNull(i + 1)
                    val newGroup = prev == null || m.date - prev.date > 3_600_000L
                    if (newGroup) {
                        Text(shortTime(m.date), fontSize = 12.sp, color = Color.Gray,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                    val lastInGroup = next == null || next.mine != m.mine || next.date - m.date > 3_600_000L || next.sender != m.sender
                    val showSender = thread.isGroup && !m.mine && (newGroup || prev!!.mine || prev.sender != m.sender)
                    val status = when {
                        m.status == Status.FAILED -> "Not Delivered"
                        i == lastMine && m.status == Status.SENDING -> "Sending…"
                        i == lastMine && m.status == Status.DELIVERED -> "Delivered"
                        i == lastMine && m.status == Status.SENT -> "Sent"
                        else -> null
                    }
                    Bubble(m, lastInGroup, dark, if (showSender) m.sender?.let { repo.nameFor(it) } else null, q,
                        flash = m.key == flashKey || m.key == currentKey, status = status, repo = repo,
                        onLong = { menu = m }, onAttachment = { a ->
                            if (a.mime.startsWith("image/")) viewing = a
                            else if (!repo.open(a)) Toast.makeText(ctx, "No app can open this", Toast.LENGTH_SHORT).show()
                        })
                }
            }

            if (pending.isNotEmpty()) {
                LazyRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pending.toList()) { a ->
                        val bmp by produceState<ImageBitmap?>(null, a.uri) { value = withContext(Dispatchers.IO) { repo.pendingThumb(a) } }
                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(glass)) {
                            bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                                ?: Icon(Icons.Default.AttachFile, null, Modifier.align(Alignment.Center), tint = Color.Gray)
                            Box(Modifier.align(Alignment.TopEnd).padding(3.dp).size(20.dp).clip(CircleShape).background(Color(0xAA000000))
                                .clickable { pending.remove(a) }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Close, "Remove", tint = Color.White, modifier = Modifier.size(13.dp))
                            }
                        }
                    }
                }
            }

            // Input bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(glass).clickable {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, "Attach", tint = Color.Gray)
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(glass)
                        .border(0.5.dp, Color.Gray.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                        .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                        if (draft.isEmpty()) Text(if (thread.isGroup || pending.isNotEmpty()) "MMS Message" else "Text Message", color = Color.Gray, fontSize = 16.sp)
                        BasicTextField(
                            draft, { draft = it }, Modifier.fillMaxWidth(),
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                            cursorBrush = SolidColor(IBlue), maxLines = 5
                        )
                    }
                    if (draft.isNotBlank() || pending.isNotEmpty()) {
                        Box(Modifier.size(30.dp).clip(CircleShape).background(IBlue).clickable { doSend() }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.ArrowUpward, "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (sheet) WallpaperSheet(thread.id, wp) { sheet = false }
    viewing?.let { ImageViewer(it, repo) { viewing = null } }

    menu?.let { m ->
        AlertDialog(
            onDismissRequest = { menu = null },
            title = { Text(shortTime(m.date) + if (m.isMms) " · MMS" else "") },
            text = {
                Column {
                    if (m.body.isNotEmpty()) TextButton(onClick = { clipboard.setText(AnnotatedString(m.body)); menu = null }) { Text("Copy") }
                    if (m.status == Status.FAILED && !m.isMms && m.body.isNotEmpty()) TextButton(onClick = {
                        if (repo.delete(m)) repo.sendSms(thread.addresses.first(), m.body)
                        menu = null
                    }) { Text("Resend") }
                    TextButton(onClick = {
                        if (!repo.delete(m)) Toast.makeText(ctx, "Make Messages your default SMS app to delete", Toast.LENGTH_SHORT).show()
                        menu = null
                    }) { Text("Delete", color = Color.Red) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menu = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Bubble(
    m: Msg, tail: Boolean, dark: Boolean, senderName: String?, query: String, flash: Boolean,
    status: String?, repo: SmsRepo, onLong: () -> Unit, onAttachment: (Attachment) -> Unit
) {
    val bg = when {
        m.mine -> IBlue
        dark -> Color(0xFF2C2C2E)
        else -> Color(0xFFE9E9EB)
    }
    val fg = if (m.mine || dark) Color.White else Color.Black
    val big = 19.dp; val small = 5.dp
    val shape = RoundedCornerShape(
        topStart = big, topEnd = big,
        bottomStart = if (!m.mine && tail) small else big,
        bottomEnd = if (m.mine && tail) small else big
    )
    val hasText = m.body.isNotBlank() || !m.subject.isNullOrBlank()
    Column(
        Modifier.fillMaxWidth().padding(top = 2.dp, bottom = if (tail && status == null) 6.dp else 0.dp),
        horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start
    ) {
        if (senderName != null) Text(senderName, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(start = 12.dp, bottom = 2.dp))
        m.attachments.forEach { a ->
            AttachmentView(a, repo, flash, onLong) { onAttachment(a) }
            Spacer(Modifier.height(2.dp))
        }
        if (hasText) {
            Box(
                Modifier.widthIn(max = 290.dp).clip(shape).background(bg)
                    .then(if (flash) Modifier.border(2.dp, Color(0xFFFFC107), shape) else Modifier)
                    .combinedClickable(onClick = {}, onLongClick = onLong)
                    .padding(horizontal = 13.dp, vertical = 8.dp)
            ) {
                Column {
                    if (!m.subject.isNullOrBlank()) Text(m.subject, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (m.body.isNotBlank()) Text(styledText(m.body, query, if (m.mine) Color.White else IBlue), color = fg, fontSize = 16.sp)
                }
            }
        }
        if (status != null) Text(status, fontSize = 11.sp, color = if (status == "Not Delivered") Color.Red else Color.Gray,
            modifier = Modifier.padding(top = 2.dp, end = 4.dp, bottom = 6.dp))
    }
}

@Composable
fun AttachmentView(a: Attachment, repo: SmsRepo, flash: Boolean, onLong: () -> Unit, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val visual = a.mime.startsWith("image/") || a.mime.startsWith("video/")
    val base = Modifier.clip(shape)
        .then(if (flash) Modifier.border(2.dp, Color(0xFFFFC107), shape) else Modifier)
        .combinedClickable(onClick = onClick, onLongClick = onLong)
    if (visual) {
        val bmp by produceState<ImageBitmap?>(null, a.partId) { value = withContext(Dispatchers.IO) { repo.thumb(a) } }
        Box(base, contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(b, null, Modifier.widthIn(max = 240.dp).heightIn(max = 320.dp), contentScale = ContentScale.Fit)
            else Box(Modifier.size(width = 200.dp, height = 150.dp).background(Color.Gray.copy(alpha = 0.3f)))
            if (a.mime.startsWith("video/")) Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    } else {
        Row(base.background(Color.Gray.copy(alpha = 0.25f)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AttachFile, null, tint = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.width(8.dp))
            Text(a.name ?: a.mime, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 200.dp),
                color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun ImageViewer(att: Attachment, repo: SmsRepo, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, att.partId) { value = withContext(Dispatchers.IO) { repo.load(att, 2048) } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onClose)) {
            bmp?.let { Image(it, null, Modifier.fillMaxSize().systemBarsPadding(), contentScale = ContentScale.Fit) }
            Row(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) {
                IconButton(onClick = { if (!repo.share(att)) Toast.makeText(ctx, "Couldn't share", Toast.LENGTH_SHORT).show() }) {
                    Icon(Icons.Default.Share, "Share", tint = Color.White)
                }
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperSheet(threadId: Long, wp: WallpaperStore, onDismiss: () -> Unit) {
    var forAll by remember { mutableStateOf(!wp.hasOverride(threadId)) }
    val key = if (forAll) "all" else wp.keyFor(threadId)
    val current = wp.get(threadId)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) wp.setImage(key, uri)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Chat wallpaper", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Use for all chats", Modifier.weight(1f))
                Switch(forAll, { forAll = it })
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.heightIn(max = 260.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(Presets) { p ->
                    Box(
                        Modifier.aspectRatio(0.62f).clip(RoundedCornerShape(14.dp))
                            .background(Brush.verticalGradient(p.colors))
                            .border(if (current.preset == p.id) 3.dp else 0.dp, IBlue, RoundedCornerShape(14.dp))
                            .clickable { wp.setPreset(key, p.id) },
                        contentAlignment = Alignment.BottomCenter
                    ) { Text(p.name, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(6.dp)) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Dim", fontSize = 14.sp, color = Color.Gray)
            Slider(current.dim, { wp.setDim(key, it) }, valueRange = 0f..0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Choose photo")
                }
                OutlinedButton(onClick = { wp.reset(key) }) { Text("Reset") }
            }
        }
    }
}
