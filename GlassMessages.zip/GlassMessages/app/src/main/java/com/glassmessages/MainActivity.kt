package com.glassmessages

import android.Manifest
import android.app.role.RoleManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = SmsRepo(applicationContext)
        val wp = WallpaperStore(applicationContext)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                App(repo, wp)
            }
        }
    }
}

private val perms = arrayOf(
    Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
    Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS
)

@Composable
fun App(repo: SmsRepo, wp: WallpaperStore) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ctx.checkSelfPermission(Manifest.permission.READ_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = it[Manifest.permission.READ_SMS] == true
    }
    var isDefault by remember { mutableStateOf(repo.isDefault()) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isDefault = repo.isDefault()
    }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(perms) }

    var open by remember { mutableStateOf<ChatThread?>(null) }
    BackHandler(open != null) { open = null }

    if (!granted) {
        PermissionGate { permLauncher.launch(perms) }
        return
    }
    val thread = open
    if (thread == null) {
        ConversationsScreen(
            repo = repo,
            showDefaultBanner = !isDefault && Build.VERSION.SDK_INT >= 29,
            onMakeDefault = {
                val rm = ctx.getSystemService(RoleManager::class.java)
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
            },
            onOpen = { open = it }
        )
    } else {
        ChatScreen(thread, repo, wp) { open = null }
    }
}
