@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)

package com.glassmessages

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

val IBlue = Color(0xFF0A84FF)

fun shortTime(t: Long): String {
    val now = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val fmt = when {
        now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR) && now.get(Calendar.YEAR) == d.get(Calendar.YEAR) -> "h:mm a"
        now.timeInMillis - t < 6 * 86_400_000L -> "EEEE"
        else -> "M/d/yy"
    }
    return SimpleDateFormat(fmt, Locale.getDefault()).format(Date(t))
}

@Composable
fun Avatar(name: String, size: Int, group: Boolean = false) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFFA5ABB8), Color(0xFF7D8390)))),
        contentAlignment = Alignment.Center
    ) {
        if (group) Icon(Icons.Default.Group, null, tint = Color.White, modifier = Modifier.size((size * 0.55f).dp))
        else Text(name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#", color = Color.White,
            fontSize = (size * 0.42f).sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PermissionGate(onAsk: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Messages needs access to your texts", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAsk) { Text("Allow access") }
    }
}

/** Bold + blue matches, trimmed to a window around the first match. */
fun highlighted(text: String, q: String): AnnotatedString {
    val flat = text.replace('\n', ' ')
    var s = 0
    val first = flat.indexOf(q, ignoreCase = true)
    var t = flat
    if (first > 30) { s = first - 25; t = "…" + flat.substring(s) }
    return buildAnnotatedString {
        append(t)
        var i = t.indexOf(q, ignoreCase = true)
        while (i >= 0 && q.isNotEmpty()) {
            addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = IBlue), i, i + q.length)
            i = t.indexOf(q, i + q.length, ignoreCase = true)
        }
    }
}

@Composable private fun pageBg() = if (isSystemInDarkTheme()) Color.Black else Color(0xFFF2F2F7)
@Composable private fun cardBg() = if (isSystemInDarkTheme()) Color(0xFF1C1C1E) else Color.White

private fun cardShape(i: Int, n: Int): Shape {
    val r = 20.dp
    val top = if (i == 0) r else 0.dp
    val bottom = if (i == n - 1) r else 0.dp
    return RoundedCornerShape(topStart = top, topEnd = top, bottomStart = bottom, bottomEnd = bottom)
}

@Composable
private fun ThreadRow(
    t: ChatThread, snippet: AnnotatedString, date: Long, index: Int, count: Int,
    onClick: () -> Unit, onLong: () -> Unit = {}
) {
    Column(Modifier.fillMaxWidth().clip(cardShape(index, count)).background(cardBg()).combinedClickable(onClick = onClick, onLongClick = onLong)) {
        Row(Modifier.padding(end = 14.dp, top = 11.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(22.dp), contentAlignment = Alignment.Center) {
                if (t.unread) Box(Modifier.size(10.dp).clip(CircleShape).background(IBlue))
            }
            Avatar(t.name, 50, t.isGroup)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.name, fontWeight = if (t.unread) FontWeight.Bold else FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Text(shortTime(date), fontSize = 13.sp, color = if (t.unread) IBlue else Color.Gray)
                }
                Spacer(Modifier.height(2.dp))
                Text(snippet, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, lineHeight = 19.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (index != count - 1) HorizontalDivider(Modifier.padding(start = 84.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
    }
}

@Composable
private fun SectionLabel(s: String) =
    Text(s, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray,
        modifier = Modifier.padding(start = 8.dp, top = 16.dp, bottom = 6.dp))

@Composable
fun ConversationsScreen(
    repo: SmsRepo, showDefaultBanner: Boolean, onMakeDefault: () -> Unit,
    onOpen: (ChatThread, String?) -> Unit, onNew: () -> Unit
) {
    val ctx = LocalContext.current
    val threads by remember { repo.threadsFlow() }.collectAsState(emptyList())
    var query by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<ChatThread?>(null) }
    val q = query.trim()
    val hits by produceState(emptyList<SearchHit>(), q) {
        value = if (q.length < 2) emptyList() else { delay(250); withContext(Dispatchers.IO) { repo.search(q) } }
    }
    val byId = remember(threads) { threads.associateBy { it.id } }
    val matched = remember(threads, q) {
        if (q.isEmpty()) emptyList() else threads.filter { t ->
            t.name.contains(q, true) || t.addresses.any { it.contains(q, true) }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().background(pageBg()).statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 8.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Messages", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Box(Modifier.size(42.dp).clip(CircleShape).background(cardBg()).clickable(onClick = onNew), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Edit, "New message", tint = IBlue, modifier = Modifier.size(20.dp))
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(cardBg())
                    .padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search", color = Color.Gray, fontSize = 16.sp)
                    BasicTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                        textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                        cursorBrush = SolidColor(IBlue))
                }
                if (query.isNotEmpty()) Icon(Icons.Default.Close, "Clear", tint = Color.Gray,
                    modifier = Modifier.size(20.dp).clickable { query = "" })
            }
        }
        if (showDefaultBanner && q.isEmpty()) item {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(IBlue.copy(alpha = 0.12f))
                    .clickable(onClick = onMakeDefault).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Sms, null, tint = IBlue)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Make Messages your default app", fontWeight = FontWeight.SemiBold, color = IBlue, fontSize = 15.sp)
                    Text("Needed to send photos, group texts and to delete", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
        if (q.isEmpty()) {
            if (threads.isEmpty()) item {
                Text("No conversations yet", color = Color.Gray, modifier = Modifier.fillMaxWidth().padding(40.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
            itemsIndexed(threads, key = { _, t -> t.id }) { i, t ->
                ThreadRow(t, AnnotatedString(t.snippet), t.date, i, threads.size, { onOpen(t, null) }, { menuFor = t })
            }
        } else {
            if (matched.isNotEmpty()) {
                item { SectionLabel("Conversations") }
                itemsIndexed(matched, key = { _, t -> "c${t.id}" }) { i, t ->
                    ThreadRow(t, AnnotatedString(t.snippet), t.date, i, matched.size, { onOpen(t, null) })
                }
            }
            if (hits.isNotEmpty()) {
                item { SectionLabel("Messages") }
                itemsIndexed(hits, key = { _, h -> h.key }) { i, h ->
                    val t = byId[h.threadId] ?: ChatThread(h.threadId, listOf("Conversation"), "Conversation", "", h.date)
                    ThreadRow(t, highlighted(h.text, q), h.date, i, hits.size, { onOpen(t, h.key) })
                }
            }
            if (matched.isEmpty() && hits.isEmpty()) item {
                Text("No results", color = Color.Gray, modifier = Modifier.fillMaxWidth().padding(32.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }

    menuFor?.let { t ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    if (t.unread) TextButton(onClick = { repo.markRead(t.id); menuFor = null }) { Text("Mark as read") }
                    if (!t.isGroup) TextButton(onClick = {
                        if (!repo.editContact(t.addresses[0])) Toast.makeText(ctx, "No contacts app found", Toast.LENGTH_SHORT).show()
                        menuFor = null
                    }) { Text("Edit contact") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!repo.deleteThread(t.id)) Toast.makeText(ctx, "Make Messages your default SMS app to delete", Toast.LENGTH_SHORT).show()
                    menuFor = null
                }) { Text("Delete conversation", color = Color.Red) }
            },
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun NewMessageScreen(repo: SmsRepo, onCancel: () -> Unit, onStart: (List<String>) -> Unit) {
    val recipients = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    val suggestions by produceState(emptyList<Pair<String, String>>(), input) {
        value = if (input.isBlank()) emptyList() else withContext(Dispatchers.IO) { repo.searchContacts(input.trim()) }
    }
    val typed = input.trim()
    val looksNumber = typed.isNotEmpty() && typed.all { it.isDigit() || it in "+-() ." }
    fun add(name: String, num: String) { if (recipients.none { it.second == num }) recipients.add(name to num); input = "" }

    Column(Modifier.fillMaxSize().background(pageBg()).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onCancel) { Text("Cancel", color = IBlue) }
            Text("New Message", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            TextButton(enabled = recipients.isNotEmpty() || looksNumber, onClick = {
                val l = recipients.map { it.second }.toMutableList()
                if (looksNumber) l.add(typed)
                onStart(l)
            }) { Text("Chat") }
        }
        HorizontalDivider(thickness = 0.5.dp)
        FlowRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("To:", color = Color.Gray)
            recipients.forEach { r ->
                Row(Modifier.clip(RoundedCornerShape(50)).background(IBlue.copy(alpha = 0.15f)).clickable { recipients.remove(r) }
                    .padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(r.first, color = IBlue, fontSize = 15.sp)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.Close, "Remove", tint = IBlue, modifier = Modifier.size(14.dp))
                }
            }
            BasicTextField(input, { input = it }, Modifier.widthIn(min = 120.dp), singleLine = true,
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp), cursorBrush = SolidColor(IBlue),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (typed.isNotEmpty()) add(typed, typed) }))
        }
        HorizontalDivider(thickness = 0.5.dp)
        LazyColumn(Modifier.weight(1f)) {
            if (looksNumber) item {
                Text("Send to $typed", color = IBlue, modifier = Modifier.fillMaxWidth().clickable { add(typed, typed) }.padding(16.dp))
            }
            items(suggestions, key = { it.second }) { (name, num) ->
                Column(Modifier.fillMaxWidth().clickable { add(name, num) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(num, fontSize = 13.sp, color = Color.Gray)
                }
            }
        }
    }
}
