package com.glassmessages

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

val IBlue = Color(0xFF0A84FF)

fun shortTime(t: Long): String {
    val now = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val fmt = when {
        now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR) && now.get(Calendar.YEAR) == d.get(Calendar.YEAR) -> "h:mm a"
        now.timeInMillis - t < 6 * 86_400_000L -> "EEEE"
        else -> "M/d/yy"
    }
    return SimpleDateFormat(fmt, Locale.getDefault()).format(Date(t))
}

@Composable
fun Avatar(name: String, size: Int) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFFA5ABB8), Color(0xFF7D8390)))),
        contentAlignment = Alignment.Center
    ) {
        Text(name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#", color = Color.White,
            fontSize = (size * 0.42f).sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PermissionGate(onAsk: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Messages needs access to your texts", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAsk) { Text("Allow access") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationsScreen(
    repo: SmsRepo, showDefaultBanner: Boolean, onMakeDefault: () -> Unit, onOpen: (ChatThread) -> Unit
) {
    val threads by remember { repo.threadsFlow() }.collectAsState(emptyList())
    var newDialog by remember { mutableStateOf(false) }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            item {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Messages", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { newDialog = true }) { Icon(Icons.Default.Edit, "New message", tint = IBlue) }
                }
            }
            if (showDefaultBanner) item {
                TextButton(onClick = onMakeDefault, Modifier.padding(horizontal = 12.dp)) {
                    Text("Make this your default SMS app to send and receive here", color = IBlue)
                }
            }
            items(threads, key = { it.id }) { t ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(t) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(t.name, 48)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row {
                            Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text(shortTime(t.date), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(t.snippet, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider(Modifier.padding(start = 76.dp), thickness = 0.5.dp)
            }
        }
    }

    if (newDialog) {
        var num by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newDialog = false },
            title = { Text("New message") },
            text = { OutlinedTextField(num, { num = it }, label = { Text("Phone number") }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = num.isNotBlank(), onClick = {
                    newDialog = false
                    onOpen(ChatThread(repo.threadIdFor(num.trim()), num.trim(), repo.nameFor(num.trim()), "", 0))
                }) { Text("Start") }
            },
            dismissButton = { TextButton(onClick = { newDialog = false }) { Text("Cancel") } }
        )
    }
}
