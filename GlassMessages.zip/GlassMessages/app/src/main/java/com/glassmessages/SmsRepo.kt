package com.glassmessages

import android.Manifest
import android.app.PendingIntent
import android.content.*
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.LruCache
import android.webkit.MimeTypeMap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

data class ChatThread(
    val id: Long, val addresses: List<String>, val name: String,
    val snippet: String, val date: Long, val unread: Boolean = false
) {
    val isGroup get() = addresses.size > 1
}

data class Attachment(val partId: Long, val mime: String, val name: String?)
enum class Status { NONE, SENDING, SENT, DELIVERED, FAILED }
data class Msg(
    val key: String, val id: Long, val isMms: Boolean, val body: String, val date: Long, val mine: Boolean,
    val sender: String?, val attachments: List<Attachment>, val status: Status, val subject: String?
)
data class PendingAttachment(val uri: Uri, val mime: String)
data class SearchHit(val threadId: Long, val key: String, val text: String, val date: Long)
class Incoming(val threadId: Long, val addresses: List<String>, val preview: String)

class SmsRepo(context: Context) {
    private val ctx = context.applicationContext
    private val names = HashMap<String, String>()
    private val canon = HashMap<Long, String>()
    private val senders = HashMap<Long, String?>()
    private val thumbs = LruCache<Long, ImageBitmap>(80)

    companion object {
        const val ACT_MMS_SENT = "com.glassmessages.MMS_SENT"
        const val ACT_MMS_DL = "com.glassmessages.MMS_DOWNLOADED"
        const val ACT_SMS_SENT = "com.glassmessages.SMS_SENT"
        const val ACT_SMS_DELIVERED = "com.glassmessages.SMS_DELIVERED"
        private val SIMPLE_THREADS = Telephony.Threads.CONTENT_URI.buildUpon().appendQueryParameter("simple", "true").build()
        private const val MAX_MMS_BYTES = 1_000_000
    }

    // ------------------------------------------------------------ contacts

    fun nameFor(address: String): String = names[address] ?: run {
        var n = address
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
                ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) n = it.getString(0) ?: address
                }
            } catch (_: Exception) { }
        }
        names[address] = n
        n
    }

    fun searchContacts(q: String): List<Pair<String, String>> {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val out = ArrayList<Pair<String, String>>(); val seen = HashSet<String>()
        val P = ContactsContract.CommonDataKinds.Phone
        try {
            ctx.contentResolver.query(Uri.withAppendedPath(P.CONTENT_FILTER_URI, Uri.encode(q)),
                arrayOf(P.DISPLAY_NAME, P.NUMBER), null, null, P.DISPLAY_NAME + " ASC")?.use { c ->
                while (c.moveToNext() && out.size < 25) {
                    val n = c.getString(1) ?: continue
                    if (seen.add(n.filter { it.isDigit() })) out += (c.getString(0) ?: n) to n
                }
            }
        } catch (_: Exception) { }
        return out
    }

    private val selfNums: List<String> by lazy {
        try {
            listOfNotNull(ctx.getSystemService(TelephonyManager::class.java)?.line1Number).filter { it.isNotBlank() }
        } catch (_: SecurityException) { emptyList() }
    }
    private fun isSelf(a: String) = selfNums.any { PhoneNumberUtils.compare(it, a) }
    private fun List<String>.dedupe(): List<String> {
        val o = ArrayList<String>()
        for (a in this) if (o.none { PhoneNumberUtils.compare(it, a) }) o += a
        return o
    }

    // ------------------------------------------------------------ flows

    private fun changes() = callbackFlow<Unit> {
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { trySend(Unit) }
        }
        for (u in listOf("content://sms", "content://mms", "content://mms-sms"))
            ctx.contentResolver.registerContentObserver(Uri.parse(u), true, o)
        trySend(Unit)
        awaitClose { ctx.contentResolver.unregisterContentObserver(o) }
    }

    fun threadsFlow() = changes().conflate().map { threads() }.flowOn(Dispatchers.IO)
    fun messagesFlow(t: ChatThread) = changes().conflate().map { messages(t) }.flowOn(Dispatchers.IO)

    // ------------------------------------------------------------ threads

    private fun canonical(id: Long): String {
        canon[id]?.let { return it }
        try {
            ctx.contentResolver.query(Uri.parse("content://mms-sms/canonical-address/$id"), null, null, null, null)?.use {
                if (it.moveToFirst()) { val a = it.getString(0) ?: ""; if (a.isNotEmpty()) canon[id] = a; return a }
            }
        } catch (_: Exception) { }
        return ""
    }

    private fun threads(): List<ChatThread> {
        val out = ArrayList<ChatThread>()
        ctx.contentResolver.query(SIMPLE_THREADS, arrayOf("_id", "recipient_ids", "snippet", "date", "read", "message_count"),
            null, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                if (c.getInt(5) == 0) continue
                var addrs = (c.getString(1) ?: "").split(" ").mapNotNull { it.toLongOrNull() }.map { canonical(it) }.filter { it.isNotEmpty() }
                if (addrs.isEmpty()) addrs = listOf("Unknown")
                val snip = (c.getString(2) ?: "").ifBlank { "Attachment" }
                out += ChatThread(c.getLong(0), addrs, addrs.joinToString(", ") { nameFor(it) }, snip, c.getLong(3), c.getInt(4) == 0)
            }
        }
        return out
    }

    fun threadIdFor(addresses: List<String>): Long = Telephony.Threads.getOrCreateThreadId(ctx, addresses.toSet())

    // ------------------------------------------------------------ messages

    private fun partUri(id: Long) = Uri.parse("content://mms/part/$id")

    private fun readPartText(id: Long): String = try {
        ctx.contentResolver.openInputStream(partUri(id))?.use { String(it.readBytes()) } ?: ""
    } catch (_: Exception) { "" }

    private fun senderOf(mmsId: Long): String? = senders.getOrPut(mmsId) {
        var s: String? = null
        try {
            ctx.contentResolver.query(Uri.parse("content://mms/$mmsId/addr"), arrayOf("address", "type"), "type=137", null, null)?.use {
                if (it.moveToFirst()) s = it.getString(0)
            }
        } catch (_: Exception) { }
        s
    }

    private fun messages(t: ChatThread): List<Msg> {
        val cr = ctx.contentResolver; val tid = t.id.toString()
        val out = ArrayList<Msg>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "body", "date", "type", "status"),
            "thread_id=? AND type!=3", arrayOf(tid), "date ASC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0); val type = c.getInt(3); val st = c.getInt(4)
                val mine = type != Telephony.Sms.MESSAGE_TYPE_INBOX
                val status = when {
                    !mine -> Status.NONE
                    type == 4 || type == 6 -> Status.SENDING
                    type == 5 || st >= 64 -> Status.FAILED
                    st == 0 -> Status.DELIVERED
                    else -> Status.SENT
                }
                out += Msg("s$id", id, false, c.getString(1) ?: "", c.getLong(2), mine, null, emptyList(), status, null)
            }
        }

        class Row(val id: Long, val date: Long, val box: Int, val sub: String?)
        val rows = ArrayList<Row>()
        cr.query(Telephony.Mms.CONTENT_URI, arrayOf("_id", "date", "msg_box", "sub"),
            "thread_id=? AND m_type IN (128,132) AND msg_box!=3", arrayOf(tid), "date ASC")?.use { c ->
            while (c.moveToNext()) rows += Row(c.getLong(0), c.getLong(1) * 1000, c.getInt(2), c.getString(3))
        }
        if (rows.isNotEmpty()) {
            val texts = HashMap<Long, StringBuilder>()
            val atts = HashMap<Long, MutableList<Attachment>>()
            cr.query(Uri.parse("content://mms/part"), arrayOf("_id", "mid", "ct", "name", "text", "cl"),
                "mid IN (${rows.joinToString(",") { it.id.toString() }})", null, "seq ASC")?.use { c ->
                while (c.moveToNext()) {
                    val pid = c.getLong(0); val mid = c.getLong(1); val ct = (c.getString(2) ?: "").lowercase()
                    when {
                        ct == "text/plain" -> {
                            val tx = c.getString(4) ?: readPartText(pid)
                            if (tx.isNotEmpty()) texts.getOrPut(mid) { StringBuilder() }.apply { if (isNotEmpty()) append('\n'); append(tx) }
                        }
                        ct.isEmpty() || ct == "application/smil" || ct == "text/html" -> {}
                        else -> atts.getOrPut(mid) { mutableListOf() }.add(Attachment(pid, ct, c.getString(3) ?: c.getString(5)))
                    }
                }
            }
            for (r in rows) {
                val mine = r.box != 1
                val status = when (r.box) { 4 -> Status.SENDING; 5 -> Status.FAILED; 2 -> Status.SENT; else -> Status.NONE }
                out += Msg("m${r.id}", r.id, true, texts[r.id]?.toString() ?: "", r.date, mine,
                    if (!mine && t.isGroup) senderOf(r.id) else null, atts[r.id] ?: emptyList(), status, r.sub?.takeIf { it.isNotBlank() })
            }
        }
        out.sortBy { it.date }
        return out
    }

    // ------------------------------------------------------------ search

    fun search(q: String): List<SearchHit> {
        val cr = ctx.contentResolver
        val pat = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        val out = ArrayList<SearchHit>()
        try {
            cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "body", "date"),
                "body LIKE ? ESCAPE '\\'", arrayOf(pat), "date DESC")?.use { c ->
                while (c.moveToNext() && out.size < 100) out += SearchHit(c.getLong(1), "s${c.getLong(0)}", c.getString(2) ?: "", c.getLong(3))
            }
            val mids = LinkedHashMap<Long, String>()
            cr.query(Uri.parse("content://mms/part"), arrayOf("mid", "text"),
                "ct='text/plain' AND text LIKE ? ESCAPE '\\'", arrayOf(pat), null)?.use { c ->
                while (c.moveToNext() && mids.size < 100) mids[c.getLong(0)] = c.getString(1) ?: ""
            }
            if (mids.isNotEmpty()) {
                cr.query(Telephony.Mms.CONTENT_URI, arrayOf("_id", "thread_id", "date"),
                    "_id IN (${mids.keys.joinToString(",")})", null, null)?.use { c ->
                    while (c.moveToNext()) out += SearchHit(c.getLong(1), "m${c.getLong(0)}", mids[c.getLong(0)] ?: "", c.getLong(2) * 1000)
                }
            }
        } catch (_: Exception) { }
        return out.sortedByDescending { it.date }
    }

    // ------------------------------------------------------------ state changes

    fun isDefault() = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun markRead(threadId: Long) {
        if (!isDefault()) return
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        val a = arrayOf(threadId.toString())
        try {
            ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, v, "thread_id=? AND read=0", a)
            ctx.contentResolver.update(Telephony.Mms.CONTENT_URI, v, "thread_id=? AND read=0", a)
        } catch (_: Exception) { }
    }

    fun delete(m: Msg): Boolean {
        if (!isDefault()) return false
        return try {
            ctx.contentResolver.delete(Uri.parse(if (m.isMms) "content://mms/${m.id}" else "content://sms/${m.id}"), null, null) > 0
        } catch (_: Exception) { false }
    }

    fun deleteThread(id: Long): Boolean {
        if (!isDefault()) return false
        return try { ctx.contentResolver.delete(Uri.parse("content://mms-sms/conversations/$id"), null, null) > 0 } catch (_: Exception) { false }
    }

    // ------------------------------------------------------------ sending

    private fun smsManager(): SmsManager = ctx.getSystemService(SmsManager::class.java)

    private fun smsPi(action: String, uri: Uri, part: Int) = PendingIntent.getBroadcast(
        ctx, part, Intent(ctx, SmsStatusReceiver::class.java).setAction(action).setData(uri),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)

    fun sendSms(address: String, text: String) {
        val sm = smsManager()
        val parts = sm.divideMessage(text)
        var uri: Uri? = null
        if (isDefault()) {
            val v = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address); put(Telephony.Sms.BODY, text)
                put(Telephony.Sms.DATE, System.currentTimeMillis()); put(Telephony.Sms.READ, 1); put("seen", 1)
            }
            uri = ctx.contentResolver.insert(Telephony.Sms.Outbox.CONTENT_URI, v)
        }
        val sent = ArrayList<PendingIntent>(); val deliv = ArrayList<PendingIntent>()
        if (uri != null) parts.indices.forEach { sent += smsPi(ACT_SMS_SENT, uri, it); deliv += smsPi(ACT_SMS_DELIVERED, uri, it) }
        sm.sendMultipartTextMessage(address, null, parts, if (uri != null) sent else null, if (uri != null) deliv else null)
    }

    /** Returns an error message, or null on success. */
    suspend fun send(addresses: List<String>, text: String, atts: List<PendingAttachment>): String? {
        if (addresses.isEmpty()) return "No recipient"
        if (addresses.size == 1 && atts.isEmpty()) {
            return try { sendSms(addresses[0], text); null } catch (e: Exception) { "Couldn't send: ${e.message}" }
        }
        return withContext(Dispatchers.IO) { sendMms(addresses, text, atts) }
    }

    private fun sendMms(addresses: List<String>, text: String, atts: List<PendingAttachment>): String? {
        if (!isDefault()) return "Make Messages your default SMS app to send pictures and group texts."
        return try {
            val media = ArrayList<MmsPart>()
            atts.forEachIndexed { i, a -> media += loadAttachment(a, i) ?: return "Attachment ${i + 1} is too large or unreadable (limit about 1 MB)." }
            if (text.isNotBlank()) media += MmsPart("text/plain", "text0.txt", "text0", text.toByteArray())
            val all = listOf(MmsCodec.smil(media)) + media
            if (all.sumOf { it.data.size } > MAX_MMS_BYTES + 100_000) return "Message is too large to send as MMS."
            val tid = "T" + java.lang.Long.toHexString(System.nanoTime())
            val thread = threadIdFor(addresses)
            val msgUri = storeMms(thread, 4, null, addresses, null, all, System.currentTimeMillis() / 1000, true, tid)
                ?: return "Couldn't save the message."
            val f = File(ctx.cacheDir, "mms").apply { mkdirs() }.let { File(it, "send_$tid.pdu") }
            f.writeBytes(MmsCodec.buildSendReq(tid, addresses, all))
            val pdu = fileUri(f)
            val pi = PendingIntent.getBroadcast(ctx, tid.hashCode(),
                Intent(ctx, MmsSentReceiver::class.java).setAction(ACT_MMS_SENT).setData(msgUri).putExtra("file", f.path),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            grant(pdu)
            smsManager().sendMultimediaMessage(ctx, pdu, null, null, pi)
            null
        } catch (e: Exception) { "Couldn't send MMS: ${e.message}" }
    }

    // ------------------------------------------------------------ MMS storage

    private fun storeMms(thread: Long, box: Int, from: String?, to: List<String>, subject: String?,
                         parts: List<MmsPart>, dateSec: Long, read: Boolean, tid: String?): Uri? {
        val cr = ctx.contentResolver
        val textOnly = parts.all { it.mime == "text/plain" || it.mime == "application/smil" }
        val v = ContentValues().apply {
            put("thread_id", thread); put("date", dateSec); put("date_sent", dateSec)
            put("msg_box", box); put("read", if (read) 1 else 0); put("seen", if (read) 1 else 0)
            put("m_type", if (box == 1) 132 else 128); put("v", 18)
            put("ct_t", "application/vnd.wap.multipart.related")
            put("m_size", parts.sumOf { it.data.size }); put("pri", 129); put("rr", 129); put("d_rpt", 129)
            put("text_only", if (textOnly) 1 else 0)
            if (tid != null) put("tr_id", tid)
            if (box != 1) put("exp", 604800)
            if (subject != null) { put("sub", subject); put("sub_cs", 106) }
        }
        val uri = cr.insert(Telephony.Mms.CONTENT_URI, v) ?: return null
        val id = ContentUris.parseId(uri)
        fun addr(a: String, type: Int) {
            cr.insert(Uri.parse("content://mms/$id/addr"), ContentValues().apply {
                put("msg_id", id); put("address", a); put("type", type); put("charset", 106)
            })
        }
        if (box == 1) from?.let { addr(it, 137) } else addr("insert-address-token", 137)
        to.forEach { addr(it, 151) }
        for (p in parts) {
            val inline = p.mime == "text/plain" || p.mime == "application/smil"
            val pv = ContentValues().apply {
                put("mid", id); put("ct", p.mime); put("seq", if (p.mime == "application/smil") -1 else 0)
                p.name?.let { put("name", it); put("cl", it) }
                p.cid?.let { put("cid", "<$it>") }
                if (inline) { put("chset", 106); put("text", String(p.data, charset(p.charset))) }
            }
            val pu = cr.insert(Uri.parse("content://mms/$id/part"), pv) ?: continue
            if (!inline) cr.openOutputStream(pu)?.use { it.write(p.data) }
        }
        return uri
    }

    // ------------------------------------------------------------ MMS receive

    @Synchronized fun claimMms(tid: String): Boolean {
        val p = ctx.getSharedPreferences("mms", Context.MODE_PRIVATE)
        val l = (p.getString("seen", "") ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()
        if (tid in l) return false
        l.add(tid); while (l.size > 200) l.removeAt(0)
        p.edit().putString("seen", l.joinToString("|")).apply()
        return true
    }

    @Synchronized fun releaseMms(tid: String) {
        val p = ctx.getSharedPreferences("mms", Context.MODE_PRIVATE)
        val l = (p.getString("seen", "") ?: "").split("|").filter { it.isNotEmpty() && it != tid }
        p.edit().putString("seen", l.joinToString("|")).apply()
    }

    fun downloadMms(n: MmsNotification) {
        val f = File(File(ctx.cacheDir, "mms").apply { mkdirs() }, "dl_${System.currentTimeMillis()}.pdu")
        f.createNewFile()
        val uri = fileUri(f)
        val pi = PendingIntent.getBroadcast(ctx, n.tid.hashCode(),
            Intent(ctx, MmsDownloadedReceiver::class.java).setAction(ACT_MMS_DL)
                .putExtra("file", f.path).putExtra("tid", n.tid).putExtra("from", n.from),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        grant(uri)
        smsManager().downloadMultimediaMessage(ctx, n.location, uri, null, pi)
    }

    fun saveIncoming(bytes: ByteArray, fallbackFrom: String?, tid: String?): Incoming? {
        val r = MmsCodec.parseRetrieve(bytes) ?: return null
        val sender = r.from ?: fallbackFrom ?: return null
        var people = (listOf(sender) + r.to).filter { !isSelf(it) }.dedupe()
        if (people.isEmpty()) people = listOf(sender)
        val parts = r.parts.ifEmpty { listOf(MmsPart("text/plain", "text0.txt", "text0", "[Unsupported MMS]".toByteArray())) }
        val thread = threadIdFor(people)
        storeMms(thread, 1, sender, r.to.filter { it != sender }, r.subject, parts, System.currentTimeMillis() / 1000, false, tid) ?: return null
        val text = parts.firstOrNull { it.mime == "text/plain" }?.let { String(it.data, charset(it.charset)) }?.trim()
        val preview = if (!text.isNullOrEmpty()) text else when {
            parts.any { it.mime.startsWith("image/") } -> "📷 Photo"
            parts.any { it.mime.startsWith("video/") } -> "🎞 Video"
            parts.any { it.mime.startsWith("audio/") } -> "🎵 Audio"
            else -> "Attachment"
        }
        return Incoming(thread, people, preview)
    }

    // ------------------------------------------------------------ files & images

    private fun fileUri(f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    private fun grant(uri: Uri) {
        for (pkg in listOf("com.android.phone", "com.android.mms.service")) try {
            ctx.grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) { }
    }

    private fun ext(mime: String) = when (mime) {
        "image/jpeg" -> "jpg"
        else -> MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
    }

    private fun decode(uri: Uri, maxPx: Int, exif: Boolean): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= maxPx && o.outHeight / (s * 2) >= maxPx) s *= 2
        var bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
        if (bmp != null) {
            val m = Matrix(); var changed = false
            val big = maxOf(bmp.width, bmp.height)
            if (big > maxPx) { val k = maxPx.toFloat() / big; m.postScale(k, k); changed = true }
            if (exif) {
                val rot = ctx.contentResolver.openInputStream(uri)?.use {
                    when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
                if (rot != 0f) { m.postRotate(rot); changed = true }
            }
            if (changed) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        bmp
    } catch (_: Exception) { null }

    private fun videoFrame(uri: Uri): Bitmap? = try {
        val r = MediaMetadataRetriever()
        try { r.setDataSource(ctx, uri); r.getFrameAtTime(0) } finally { r.release() }
    } catch (_: Exception) { null }

    private fun loadAttachment(a: PendingAttachment, i: Int): MmsPart? {
        val name = "att$i"
        if (a.mime.startsWith("image/") && a.mime != "image/gif") {
            var dim = 1600
            repeat(6) {
                val bmp = decode(a.uri, dim, true) ?: return null
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                if (bos.size() <= 900_000) return MmsPart("image/jpeg", "$name.jpg", name, bos.toByteArray())
                dim = dim * 3 / 4
            }
            return null
        }
        val bytes = ctx.contentResolver.openInputStream(a.uri)?.use { it.readBytes() } ?: return null
        if (bytes.size > MAX_MMS_BYTES) return null
        return MmsPart(a.mime, "$name.${ext(a.mime)}", name, bytes)
    }

    fun pendingThumb(a: PendingAttachment): ImageBitmap? =
        (if (a.mime.startsWith("video/")) videoFrame(a.uri) else decode(a.uri, 200, true))?.asImageBitmap()

    fun thumb(a: Attachment): ImageBitmap? {
        thumbs.get(a.partId)?.let { return it }
        val b = (if (a.mime.startsWith("video/")) videoFrame(partUri(a.partId)) else decode(partUri(a.partId), 600, true))?.asImageBitmap()
        if (b != null) thumbs.put(a.partId, b)
        return b
    }

    fun load(a: Attachment, maxPx: Int): ImageBitmap? = decode(partUri(a.partId), maxPx, true)?.asImageBitmap()

    private fun copyOut(a: Attachment): Uri? = try {
        val dir = File(ctx.cacheDir, "attach").apply { mkdirs() }
        val n = (a.name?.takeIf { it.isNotBlank() } ?: "attachment_${a.partId}.${ext(a.mime)}").replace(Regex("[^A-Za-z0-9._-]"), "_")
        val f = File(dir, "${a.partId}_$n")
        ctx.contentResolver.openInputStream(partUri(a.partId))?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        fileUri(f)
    } catch (_: Exception) { null }

    fun open(a: Attachment): Boolean {
        val u = copyOut(a) ?: return false
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, a.mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (_: Exception) { false }
    }

    fun share(a: Attachment): Boolean {
        val u = copyOut(a) ?: return false
        val send = Intent(Intent.ACTION_SEND).setType(a.mime).putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try { ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Exception) { false }
    }
}
