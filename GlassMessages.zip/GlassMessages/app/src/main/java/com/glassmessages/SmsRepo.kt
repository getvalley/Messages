package com.glassmessages

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*

data class ChatThread(val id: Long, val address: String, val name: String, val snippet: String, val date: Long)
data class Msg(val id: Long, val body: String, val date: Long, val mine: Boolean)

class SmsRepo(private val ctx: Context) {
    private val names = HashMap<String, String>()

    fun nameFor(address: String): String = names.getOrPut(address) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return address
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return@getOrPut it.getString(0)
        }
        address
    }

    private fun changes() = callbackFlow<Unit> {
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { trySend(Unit) }
        }
        ctx.contentResolver.registerContentObserver(Uri.parse("content://sms"), true, o)
        trySend(Unit)
        awaitClose { ctx.contentResolver.unregisterContentObserver(o) }
    }

    fun threadsFlow() = changes().map { threads() }.flowOn(Dispatchers.IO)
    fun messagesFlow(threadId: Long) = changes().map { messages(threadId) }.flowOn(Dispatchers.IO)

    private fun threads(): List<ChatThread> {
        val out = mutableListOf<ChatThread>()
        val seen = HashSet<Long>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            null, null, "date DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (!seen.add(id)) continue
                val addr = c.getString(1) ?: "Unknown"
                out += ChatThread(id, addr, nameFor(addr), c.getString(2) ?: "", c.getLong(3))
            }
        }
        return out
    }

    private fun messages(threadId: Long): List<Msg> {
        val out = mutableListOf<Msg>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms._ID, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
            "thread_id=?", arrayOf(threadId.toString()), "date ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                out += Msg(c.getLong(0), c.getString(1) ?: "", c.getLong(2), c.getInt(3) != Telephony.Sms.MESSAGE_TYPE_INBOX)
            }
        }
        return out
    }

    fun threadIdFor(address: String): Long = Telephony.Threads.getOrCreateThreadId(ctx, address)

    fun isDefault() = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun send(address: String, text: String) {
        val sm = ctx.getSystemService(SmsManager::class.java)
        sm.sendMultipartTextMessage(address, null, sm.divideMessage(text), null, null)
        // Only the default SMS app may write to the provider; others get it saved by the system.
        if (isDefault()) {
            val v = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address)
                put(Telephony.Sms.BODY, text)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.READ, 1)
            }
            ctx.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, v)
        }
    }
}
