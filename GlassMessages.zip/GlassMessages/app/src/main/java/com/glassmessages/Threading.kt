package com.glassmessages

/**
 * SMS/MMS has no native reactions or replies, so both are carried inside ordinary texts
 * and parsed back out when the conversation is loaded:
 *
 *  - Reaction:  Reacted 😂 to “original text”      (Google Messages style, iMessage "Loved “…”" is read too)
 *  - Removal:   Removed a 😂 from “original text”
 *  - Reply:     ↪ “quoted text”\nreply text
 */
data class Reaction(val emoji: String, val mine: Boolean, val by: String?)

val QuickReactions = listOf("❤️", "👍", "👎", "😂", "‼️", "❓")
val MoreReactions = listOf(
    "😍", "🥰", "😘", "😊", "😁", "🤣", "😭", "😮", "😢", "😡", "🙏", "🔥",
    "🎉", "👏", "🙌", "💯", "✅", "👀", "🤔", "😎", "🥳", "💔", "🤝", "💪",
    "😴", "🤯", "😅", "🙄", "👌", "✨", "🫶", "😬"
)

private const val REPLY_MARK = "↪"
private val replyRx = Regex("^$REPLY_MARK “(.*?)”\\n(.*)$", RegexOption.DOT_MATCHES_ALL)

fun String.flat(): String = replace(Regex("\\s+"), " ").trim()

/** (quoted text or null, the actual message text) */
fun splitReply(body: String): Pair<String?, String> {
    val m = replyRx.find(body) ?: return null to body
    return m.groupValues[1] to m.groupValues[2]
}

fun plainBody(m: Msg): String = splitReply(m.body).second

private fun mediaKind(m: Msg): String? = when {
    m.attachments.any { it.mime.startsWith("image/") } -> "image"
    m.attachments.any { it.mime.startsWith("video/") } -> "video"
    m.attachments.any { it.mime.startsWith("audio/") } -> "audio"
    m.attachments.isNotEmpty() -> "attachment"
    else -> null
}

/** What a reply shows as its quote line. */
fun quoteText(m: Msg): String {
    val t = plainBody(m).flat()
    if (t.isNotEmpty()) return if (t.length > 60) t.take(60).trimEnd() + "…" else t
    return when (mediaKind(m)) {
        "image" -> "📷 Photo"
        "video" -> "🎞 Video"
        "audio" -> "🎵 Audio"
        else -> "Attachment"
    }
}

fun buildReplyBody(quote: Msg, text: String) = "$REPLY_MARK “${quoteText(quote)}”\n$text"

fun reactionText(m: Msg, emoji: String, remove: Boolean): String {
    val t = plainBody(m).flat()
    val q = if (t.length > 120) t.take(120).trimEnd() + "…" else t
    val what = if (t.isNotEmpty()) "“$q”" else when (mediaKind(m)) {
        "image" -> "an image"; "video" -> "a video"; "audio" -> "an audio message"; else -> "an attachment"
    }
    return if (remove) "Removed a $emoji from $what" else "Reacted $emoji to $what"
}

/** True if [m] is the message a quote line (from a reply) points at. */
fun quoteMatches(m: Msg, quote: String): Boolean {
    val q = quote.removeSuffix("…").trimEnd()
    return when (quote) {
        "📷 Photo" -> m.attachments.any { it.mime.startsWith("image/") }
        "🎞 Video" -> m.attachments.any { it.mime.startsWith("video/") }
        "🎵 Audio" -> m.attachments.any { it.mime.startsWith("audio/") }
        "Attachment" -> m.attachments.isNotEmpty()
        else -> plainBody(m).flat().startsWith(q)
    }
}

private object Rx {
    val reactedText = Regex("^Reacted (\\S+) to [“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)
    val reactedMedia = Regex("^Reacted (\\S+) to (?:an?|the) (image|photo|picture|video|audio message|attachment)\\.?$")
    val removedText = Regex("^Removed (?:an? )?(.+?) (?:reaction )?from [“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)
    val removedMedia = Regex("^Removed (?:an? )?(.+?) (?:reaction )?from (?:an?|the) (image|photo|picture|video|audio message|attachment)\\.?$")
    val ios = Regex("^(Loved|Liked|Disliked|Laughed at|Emphasized|Questioned) [“\"](.*)[”\"]$", RegexOption.DOT_MATCHES_ALL)
    val iosMedia = Regex("^(Loved|Liked|Disliked|Laughed at|Emphasized|Questioned) (?:an?|the) (image|photo|picture|video|audio message|attachment)\\.?$")
    val iosMap = mapOf("Loved" to "❤️", "Liked" to "👍", "Disliked" to "👎", "Laughed at" to "😂", "Emphasized" to "‼️", "Questioned" to "❓")
}

private class Parsed(val emoji: String, val remove: Boolean, val quote: String?, val media: String?)

private fun parseReaction(body: String): Parsed? {
    val b = body.trim()
    if (b.length > 400) return null
    fun looksEmoji(s: String) = s.isNotEmpty() && !s.all { it.isLetterOrDigit() }
    Rx.reactedText.find(b)?.let { if (looksEmoji(it.groupValues[1])) return Parsed(it.groupValues[1], false, it.groupValues[2], null) }
    Rx.reactedMedia.find(b)?.let { if (looksEmoji(it.groupValues[1])) return Parsed(it.groupValues[1], false, null, it.groupValues[2]) }
    Rx.removedText.find(b)?.let { return Parsed("", true, it.groupValues[2], null) }
    Rx.removedMedia.find(b)?.let { return Parsed("", true, null, it.groupValues[2]) }
    Rx.ios.find(b)?.let { return Parsed(Rx.iosMap[it.groupValues[1]] ?: return null, false, it.groupValues[2], null) }
    Rx.iosMedia.find(b)?.let { return Parsed(Rx.iosMap[it.groupValues[1]] ?: return null, false, null, it.groupValues[2]) }
    return null
}

/**
 * Pulls reaction texts out of the message list and attaches them to the message they react to.
 * A reaction whose target can't be found stays visible as a normal text.
 */
fun applyReactions(list: List<Msg>): List<Msg> {
    if (list.none { it.body.length < 400 && (it.body.startsWith("Reacted") || it.body.startsWith("Removed") || Rx.iosMap.keys.any { k -> it.body.startsWith(k) }) }) return list
    val hidden = HashSet<Int>()
    val byTarget = HashMap<Int, LinkedHashMap<String, Reaction>>()
    for (i in list.indices) {
        val m = list[i]
        if (m.attachments.isNotEmpty()) continue
        val p = parseReaction(m.body) ?: continue
        var target = -1
        for (j in i - 1 downTo 0) {
            if (j in hidden) continue
            val c = list[j]
            val ok = if (p.quote != null) {
                val q = p.quote.flat().removeSuffix("…").trimEnd()
                q.isNotEmpty() && plainBody(c).flat().startsWith(q)
            } else {
                val k = p.media ?: break
                when (k) {
                    "image", "photo", "picture" -> c.attachments.any { it.mime.startsWith("image/") }
                    "video" -> c.attachments.any { it.mime.startsWith("video/") }
                    "audio message" -> c.attachments.any { it.mime.startsWith("audio/") }
                    else -> c.attachments.isNotEmpty()
                }
            }
            if (ok) { target = j; break }
        }
        if (target < 0) continue
        hidden += i
        val who = if (m.mine) "me" else (m.sender ?: "them")
        val map = byTarget.getOrPut(target) { LinkedHashMap() }
        if (p.remove) map.remove(who) else map[who] = Reaction(p.emoji, m.mine, if (m.mine) null else m.sender)
    }
    if (hidden.isEmpty()) return list
    val out = ArrayList<Msg>(list.size)
    for (i in list.indices) {
        if (i in hidden) continue
        val r = byTarget[i]
        out += if (r.isNullOrEmpty()) list[i] else list[i].copy(reactions = r.values.toList())
    }
    return out
}

// ---------------------------------------------------------------- search helpers

private fun digitsOf(s: String) = s.filter { it.isDigit() }

private fun isNumberQuery(q: String) = q.any { it.isDigit() } && q.all { it.isDigit() || it in "+-() ." }

/** Matches a phone number ignoring spaces, dashes and country code, e.g. "98765" finds "+91 98765 43200". */
fun addressMatches(address: String, q: String): Boolean {
    if (address.contains(q, ignoreCase = true)) return true
    if (!isNumberQuery(q)) return false
    val a = digitsOf(address); val d = digitsOf(q)
    if (d.isEmpty() || a.isEmpty()) return false
    if (a.contains(d)) return true
    // typed with a country code or leading 0 that the stored number doesn't have (or the other way round)
    if (d.length >= 7 && a.length >= 7) {
        val tail = minOf(10, minOf(a.length, d.length))
        if (a.takeLast(tail) == d.takeLast(tail)) return true
    }
    return false
}
