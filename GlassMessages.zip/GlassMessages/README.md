# Glass Messages
iMessage-style SMS app for Android (Kotlin, Jetpack Compose).

1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a real phone with a SIM. Emulators cannot send real SMS.
3. Grant the permissions, then tap the banner to make it your default SMS app.
   You can read texts without that, but sending and receiving are only fully reliable as default.

Wallpapers: tap the wallpaper icon or the name pill in any chat.
Bubble colors live in IBlue (Screens.kt) and Bubble() in ChatScreen.kt.
Not included yet: MMS, group chats, read receipts, search.
