# Glass Messages
iMessage-style SMS/MMS app for Android (Kotlin, Jetpack Compose).

1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a real phone with a SIM. Emulators cannot send real SMS/MMS.
3. Grant the permissions, then tap the banner to make it your default SMS app.
   Sending MMS/group texts, receiving MMS, deleting and mark-as-read all require being the default app.

## Features
- SMS + MMS: send/receive photos, videos, audio, subject lines (own PDU codec in Mms.kt, no extra library)
- Group chats (group MMS), sender names in groups
- Search: global (conversations + message text, SMS and MMS) and in-conversation with next/previous
- Unread dots, auto mark-as-read, notifications with Reply and Mark as read
- Delivery status under the last sent message (Sending / Sent / Delivered / Not Delivered)
- New message screen with contact suggestions, multiple recipients
- Long-press message: copy, resend (failed SMS), delete. Long-press conversation: delete, mark read
- Contacts: tap the avatar in a chat (or long-press a conversation) to edit or add the contact
- Tappable links, fullscreen image viewer with share, open other attachments externally
- sms:/smsto: links, "respond via message", per-chat wallpapers

## Notes
- True read receipts do not exist on SMS/MMS, so delivery status is shown instead.
- MMS is the least forgiving part: it depends on your carrier's MMSC. Attachments are compressed to about 1 MB.
  If downloads fail on a specific phone, check Logcat for the MmsDownloadedReceiver result code.
- Not included: RCS, per-message resend for MMS, drafts.
