package com.glassmessages

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/** Unsent text per conversation. */
class DraftStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("drafts", Context.MODE_PRIVATE)
    fun get(threadId: Long): String = p.getString(threadId.toString(), "") ?: ""
    fun set(threadId: Long, text: String) {
        p.edit().apply { if (text.isBlank()) remove(threadId.toString()) else putString(threadId.toString(), text) }.apply()
    }
}

/** Conversations pinned to the top of the list. */
class PinStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("pins", Context.MODE_PRIVATE)
    fun all(): Set<Long> = (p.getStringSet("pins", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    fun toggle(threadId: Long) {
        val s = HashSet(p.getStringSet("pins", emptySet()) ?: emptySet())
        if (!s.remove(threadId.toString())) s.add(threadId.toString())
        p.edit().putStringSet("pins", s).apply()
    }
}

/** Colour of your own bubbles: one default ("all") plus optional per-chat overrides ("t<threadId>"). null = the Sutra saffron default. */
class BubbleStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("bubbles", Context.MODE_PRIVATE)

    companion object { val tick = mutableIntStateOf(0) }

    fun keyFor(threadId: Long) = "t$threadId"
    fun hasOverride(threadId: Long): Boolean { tick.intValue; return p.contains(keyFor(threadId)) }

    fun get(threadId: Long): Color? {
        tick.intValue
        val k = if (p.contains(keyFor(threadId))) keyFor(threadId) else "all"
        return if (p.contains(k)) Color(p.getInt(k, 0)) else null
    }

    fun set(key: String, c: Color) { p.edit().putInt(key, c.toArgb()).apply(); tick.intValue++ }
    fun clear(key: String) { p.edit().remove(key).apply(); tick.intValue++ }
}
