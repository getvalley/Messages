package com.glassmessages

import android.Manifest
import android.content.ContentProviderOperation
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.ContactsContract.Data
import android.provider.ContactsContract.RawContacts
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** One phone number or email address on a contact. [id] is the Data row it came from (null = newly added). */
data class FieldValue(val id: Long?, val value: String, val type: Int)

/** What the editor shows and saves. [rawId] is null for a contact that doesn't exist yet. */
data class ContactDraft(
    val rawId: Long?, val nameRowId: Long?, val given: String, val family: String,
    val phones: List<FieldValue>, val emails: List<FieldValue>
)

/** Reads and writes contacts through ContactsContract so they can be edited without leaving the app. */
class ContactEditor(context: Context) {
    private val ctx = context.applicationContext
    private val cr get() = ctx.contentResolver

    fun canWrite() =
        ctx.checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun blank(address: String) =
        ContactDraft(null, null, "", "", listOf(FieldValue(null, address, Phone.TYPE_MOBILE)), emptyList())

    // Accounts that mirror another app's contacts and can't be edited from here.
    private val mirrored = listOf("whatsapp", "thoughtcrime", "tachyon", "telegram", "viber", "facebook", "twitter", "linkedin", "instagram")

    /** The saved contact for this number, or an empty draft pre-filled with the number. */
    fun load(address: String): ContactDraft {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return blank(address)
        try {
            val contactId = cr.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
            )?.use { if (it.moveToFirst()) it.getLong(0) else null } ?: return blank(address)

            val raws = ArrayList<Pair<Long, String>>()
            cr.query(
                RawContacts.CONTENT_URI, arrayOf(RawContacts._ID, RawContacts.ACCOUNT_TYPE),
                "${RawContacts.CONTACT_ID}=? AND ${RawContacts.DELETED}=0", arrayOf(contactId.toString()), null
            )?.use { while (it.moveToNext()) raws += it.getLong(0) to (it.getString(1) ?: "") }
            val raw = (raws.firstOrNull { r -> mirrored.none { m -> r.second.contains(m, true) } } ?: raws.firstOrNull())?.first
                ?: return blank(address)

            var nameId: Long? = null
            var given = ""; var family = ""; var display = ""
            val phones = ArrayList<FieldValue>(); val emails = ArrayList<FieldValue>()
            cr.query(
                Data.CONTENT_URI, arrayOf(Data._ID, Data.MIMETYPE, Data.DATA1, Data.DATA2, Data.DATA3),
                "${Data.RAW_CONTACT_ID}=?", arrayOf(raw.toString()), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    when (c.getString(1)) {
                        StructuredName.CONTENT_ITEM_TYPE -> if (nameId == null) {
                            nameId = id
                            display = c.getString(2) ?: ""
                            given = c.getString(3) ?: ""
                            family = c.getString(4) ?: ""
                        }
                        Phone.CONTENT_ITEM_TYPE -> phones += FieldValue(id, c.getString(2) ?: "", c.getInt(3))
                        Email.CONTENT_ITEM_TYPE -> emails += FieldValue(id, c.getString(2) ?: "", c.getInt(3))
                    }
                }
            }
            if (given.isBlank() && family.isBlank()) given = display
            return ContactDraft(raw, nameId, given, family, phones, emails)
        } catch (_: Exception) {
            return blank(address)
        }
    }

    /** Writes the differences between [orig] and [now] in one batch. Returns false if the provider refused. */
    fun save(orig: ContactDraft, now: ContactDraft): Boolean {
        val ops = ArrayList<ContentProviderOperation>()
        val raw = orig.rawId
        if (raw == null) ops += ContentProviderOperation.newInsert(RawContacts.CONTENT_URI)
            .withValue(RawContacts.ACCOUNT_TYPE, null).withValue(RawContacts.ACCOUNT_NAME, null).build()

        fun insert(mime: String, vararg kv: Pair<String, Any?>) {
            val b = ContentProviderOperation.newInsert(Data.CONTENT_URI)
            if (raw != null) b.withValue(Data.RAW_CONTACT_ID, raw) else b.withValueBackReference(Data.RAW_CONTACT_ID, 0)
            b.withValue(Data.MIMETYPE, mime)
            kv.forEach { b.withValue(it.first, it.second) }
            ops += b.build()
        }
        fun update(id: Long, vararg kv: Pair<String, Any?>) {
            val b = ContentProviderOperation.newUpdate(Data.CONTENT_URI).withSelection("${Data._ID}=?", arrayOf(id.toString()))
            kv.forEach { b.withValue(it.first, it.second) }
            ops += b.build()
        }
        fun delete(id: Long) {
            ops += ContentProviderOperation.newDelete(Data.CONTENT_URI).withSelection("${Data._ID}=?", arrayOf(id.toString())).build()
        }

        // name
        val given = now.given.trim(); val family = now.family.trim(); val nid = orig.nameRowId
        if (given.isEmpty() && family.isEmpty()) { if (nid != null) delete(nid) }
        else if (nid != null) update(nid, StructuredName.GIVEN_NAME to given, StructuredName.FAMILY_NAME to family)
        else insert(StructuredName.CONTENT_ITEM_TYPE, StructuredName.GIVEN_NAME to given, StructuredName.FAMILY_NAME to family)

        // phones and emails: delete what was removed, update what changed, insert what is new
        fun sync(mime: String, valueCol: String, typeCol: String, before: List<FieldValue>, after: List<FieldValue>, newType: Int) {
            val keep = after.filter { it.value.isNotBlank() }
            val keepIds = keep.mapNotNull { it.id }.toSet()
            before.forEach { b -> val id = b.id ?: return@forEach; if (id !in keepIds) delete(id) }
            keep.forEach { n ->
                val id = n.id
                val v = n.value.trim()
                if (id == null) insert(mime, valueCol to v, typeCol to newType)
                else {
                    val old = before.firstOrNull { it.id == id }
                    if (old == null || old.value != v) update(id, valueCol to v)
                }
            }
        }
        sync(Phone.CONTENT_ITEM_TYPE, Phone.NUMBER, Phone.TYPE, orig.phones, now.phones, Phone.TYPE_MOBILE)
        sync(Email.CONTENT_ITEM_TYPE, Email.ADDRESS, Email.TYPE, orig.emails, now.emails, Email.TYPE_OTHER)

        if (ops.isEmpty()) return true
        return try { cr.applyBatch(ContactsContract.AUTHORITY, ops); true } catch (e: Exception) {
            android.util.Log.e("Sutra", "contact save failed", e); false
        }
    }
}

/** Swallows taps so a full-screen page drawn over another screen doesn't pass them through. */
fun Modifier.blockTouches(): Modifier = pointerInput(Unit) { detectTapGestures { } }

@Composable
private fun FieldGroup(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cardBg()), content = content)
}

@Composable
private fun EditField(
    label: String, value: String, onChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text, trailing: @Composable (() -> Unit)? = null
) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(label, color = Color.Gray, fontSize = 16.sp)
            BasicTextField(
                value, onChange, Modifier.fillMaxWidth(), singleLine = true,
                textStyle = TextStyle(fontFamily = Body, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                cursorBrush = SolidColor(Accent), keyboardOptions = KeyboardOptions(keyboardType = keyboard)
            )
        }
        trailing?.invoke()
    }
}

@Composable
private fun AddRow(label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Add, null, tint = Accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, color = Accent, fontSize = 16.sp)
    }
}

/** Full-screen contact editor: edits the saved contact for [address], or creates one pre-filled with the number. */
@Composable
fun ContactEditorScreen(address: String, repo: SmsRepo, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val editor = remember { ContactEditor(ctx) }
    var original by remember { mutableStateOf<ContactDraft?>(null) }
    var given by remember { mutableStateOf("") }
    var family by remember { mutableStateOf("") }
    val phones = remember { mutableStateListOf<FieldValue>() }
    val emails = remember { mutableStateListOf<FieldValue>() }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(address) {
        val d = withContext(Dispatchers.IO) { editor.load(address) }
        original = d; given = d.given; family = d.family
        phones.clear(); phones.addAll(d.phones.ifEmpty { listOf(FieldValue(null, "", Phone.TYPE_MOBILE)) })
        emails.clear(); emails.addAll(d.emails)
    }

    fun doSave() {
        val o = original ?: return
        val now = ContactDraft(o.rawId, o.nameRowId, given, family, phones.toList(), emails.toList())
        saving = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) { editor.save(o, now) }
            saving = false
            if (ok) {
                repo.refreshContacts()
                Toast.makeText(ctx, "Contact saved", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(ctx, "Couldn't save here, opening Contacts instead", Toast.LENGTH_LONG).show()
                repo.editContact(address)
            }
            onClose()
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (editor.canWrite()) doSave()
        else Toast.makeText(ctx, "Allow contacts access to save changes", Toast.LENGTH_LONG).show()
    }

    val canSave = original != null && !saving && phones.any { it.value.isNotBlank() }
    val shownName = listOf(given, family).filter { it.isNotBlank() }.joinToString(" ").ifBlank { address }

    Column(Modifier.fillMaxSize().pageBackground().blockTouches().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("Cancel", color = Accent) }
            Text(
                if (original?.rawId != null) "Edit Contact" else "New Contact",
                fontFamily = Heading, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TextButton(enabled = canSave, onClick = {
                if (editor.canWrite()) doSave()
                else permLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS))
            }) { Text("Save", fontWeight = FontWeight.SemiBold, color = if (canSave) Accent else Color.Gray) }
        }
        HorizontalDivider(thickness = 0.5.dp)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) { Avatar(shownName, 88) }

            SectionLabel("Name")
            FieldGroup {
                EditField("First name", given, { given = it })
                HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
                EditField("Last name", family, { family = it })
            }

            SectionLabel("Phone")
            FieldGroup {
                phones.forEachIndexed { i, p ->
                    if (i > 0) HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
                    EditField("Phone", p.value, { phones[i] = p.copy(value = it) }, KeyboardType.Phone) {
                        IconButton(onClick = { phones.removeAt(i) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Close, "Remove number", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                if (phones.isNotEmpty()) HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
                AddRow("Add phone") { phones.add(FieldValue(null, "", Phone.TYPE_MOBILE)) }
            }

            SectionLabel("Email")
            FieldGroup {
                emails.forEachIndexed { i, e ->
                    if (i > 0) HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
                    EditField("Email", e.value, { emails[i] = e.copy(value = it) }, KeyboardType.Email) {
                        IconButton(onClick = { emails.removeAt(i) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Close, "Remove email", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                if (emails.isNotEmpty()) HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
                AddRow("Add email") { emails.add(FieldValue(null, "", Email.TYPE_OTHER)) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
