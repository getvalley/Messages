package com.glassmessages

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * A soft, blurred copy of the chat wallpaper. Glass surfaces in the chat draw the part of it that sits behind them,
 * so they look frosted instead of just see-through.
 */
class Backdrop(val image: ImageBitmap?, val colors: List<Color>?, val base: Color, val dim: Float, val size: IntSize)

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

private fun boxBlur(src: Bitmap, passes: Int): Bitmap {
    val w = src.width; val h = src.height
    var px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    repeat(passes) {
        val out = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var r = 0; var g = 0; var b = 0; var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx; val yy = y + dy
                if (xx in 0 until w && yy in 0 until h) {
                    val p = px[yy * w + xx]
                    r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
                }
            }
            out[y * w + x] = (0xFF shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
        px = out
    }
    return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
}

/** The photo shrunk to a few dozen pixels and softened; scaled back up it reads as a heavy blur and costs almost nothing to draw. */
private fun blurredPhoto(path: String): ImageBitmap? {
    try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 96 && o.outHeight / (s * 2) >= 96) s *= 2
        val b = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val k = 40f / maxOf(b.width, b.height)
        val small = if (k < 1f) Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true) else b
        return boxBlur(small, 2).asImageBitmap()
    } catch (_: Exception) {
        return null
    }
}

@Composable
fun rememberBackdrop(w: Wallpaper, size: IntSize): Backdrop {
    val bg = MaterialTheme.colorScheme.background
    val img = remember(w.imagePath) { w.imagePath?.let { blurredPhoto(it) } }
    val preset = Presets.firstOrNull { it.id == w.preset }
    return remember(img, preset, bg, w.dim, size) { Backdrop(img, preset?.colors, bg, w.dim, size) }
}

/** Paints the wallpaper backdrop as if the draw area started at [origin] on the screen (same crop as the real wallpaper). */
private fun DrawScope.drawBackdrop(b: Backdrop, origin: Offset) {
    if (b.size.width <= 0 || b.size.height <= 0) return
    val w = b.size.width.toFloat(); val h = b.size.height.toFloat()
    translate(-origin.x, -origin.y) {
        val img = b.image
        if (img != null) {
            val bw = img.width.toFloat(); val bh = img.height.toFloat()
            val screenAspect = w / h
            val sw: Float; val sh: Float
            if (bw / bh > screenAspect) { sh = bh; sw = bh * screenAspect } else { sw = bw; sh = bw / screenAspect }
            drawImage(
                img,
                srcOffset = IntOffset(((bw - sw) / 2f).toInt(), ((bh - sh) / 2f).toInt()),
                srcSize = IntSize(maxOf(1, sw.toInt()), maxOf(1, sh.toInt())),
                dstOffset = IntOffset.Zero,
                dstSize = IntSize(b.size.width, b.size.height),
                filterQuality = FilterQuality.High
            )
        } else if (b.colors != null) {
            drawRect(Brush.verticalGradient(b.colors, startY = 0f, endY = h), size = Size(w, h))
        } else {
            drawRect(b.base, size = Size(w, h))
        }
        if (b.dim > 0f) drawRect(Color.Black.copy(alpha = b.dim), size = Size(w, h))
    }
}

@Composable
fun glassTint(): Color = if (isSystemInDarkTheme()) Color(0x33FFFFFF) else Color(0x99FFFFFF)

/**
 * Frosted glass: clips to [shape], shows the blurred wallpaper behind it (inside a chat), lays a translucent [tint] over it
 * and adds a thin light edge. Outside a chat there is no wallpaper, so it is simply tinted translucent glass.
 */
@Composable
fun Modifier.backdropGlass(shape: Shape, tint: Color = glassTint(), edge: Boolean = true): Modifier {
    val backdrop = LocalBackdrop.current
    val dark = isSystemInDarkTheme()
    var origin by remember { mutableStateOf(Offset.Zero) }
    var m: Modifier = this.clip(shape)
    if (backdrop != null) m = m.onGloballyPositioned { origin = it.positionInWindow() }.drawBehind { drawBackdrop(backdrop, origin) }
    m = m.background(tint)
    if (edge) m = m.border(
        0.6.dp,
        Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.30f else 0.85f), Color.White.copy(alpha = if (dark) 0.06f else 0.25f))),
        shape
    )
    return m
}

/** Page background with two soft colour glows, so the translucent glass cards on top have something to refract. */
@Composable
fun Modifier.pageBackground(): Modifier {
    val base = pageBg()
    val a = if (isSystemInDarkTheme()) 0.24f else 0.22f
    return this.background(base).drawBehind {
        drawRect(Brush.radialGradient(listOf(Accent.copy(alpha = a), Color.Transparent),
            center = Offset(size.width * 0.1f, size.height * 0.04f), radius = size.maxDimension * 0.6f))
        drawRect(Brush.radialGradient(listOf(Color(0xFF3A5BFF).copy(alpha = a * 0.8f), Color.Transparent),
            center = Offset(size.width * 0.95f, size.height * 0.88f), radius = size.maxDimension * 0.55f))
    }
}
