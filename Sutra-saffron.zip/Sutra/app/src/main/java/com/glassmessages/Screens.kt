@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)

package com.glassmessages

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

val Accent = Color(0xFFE87B00) // Sutra saffron
val Navy = Color(0xFF1C2B7A)  // Sutra navy

fun shortTime(t: Long): String {
    val now = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val fmt = when {
        now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR) && now.get(Calendar.YEAR) == d.get(Calendar.YEAR) -> "h:mm a"
        now.timeInMillis - t < 6 * 86_400_000L -> "EEEE"
        else -> "M/d/yy"
    }
    return SimpleDateFormat(fmt, Locale.getDefault()).format(Date(t))
}

/** Centered separator text in a chat: "Today 6:33 PM", "Yesterday 9:10 AM", "Tuesday 4:02 PM", "Nov 3, 7:15 PM". */
fun dayLabel(t: Long): String {
    fun startOfDay(ms: Long) = Calendar.getInstance().apply {
        timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val days = Math.round((startOfDay(System.currentTimeMillis()) - startOfDay(t)) / 86_400_000.0).toInt()
    val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))
    val sameYear = Calendar.getInstance().get(Calendar.YEAR) == Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.YEAR)
    return when {
        days <= 0 -> "Today $time"
        days == 1 -> "Yesterday $time"
        days < 7 -> SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(t)) + " $time"
        sameYear -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(t)) + ", $time"
        else -> SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(t)) + ", $time"
    }
}

private val avatarColors = listOf(
    Color(0xFFFF9F6B) to Color(0xFFF2635F), Color(0xFF6EC6FF) to Color(0xFF3A86F5), Color(0xFF8EE08E) to Color(0xFF39A96B),
    Color(0xFFC59CFF) to Color(0xFF7D5BE6), Color(0xFFFFD66B) to Color(0xFFF2A33A), Color(0xFFFF8FB8) to Color(0xFFE5558A),
    Color(0xFF6FE0D2) to Color(0xFF2BA6A0), Color(0xFF9AA8FF) to Color(0xFF5566E0)
)

@Composable
fun Avatar(name: String, size: Int, group: Boolean = false) {
    val (top, bottom) = if (group) Color(0xFFA5ABB8) to Color(0xFF7D8390)
        else avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(top, bottom))),
        contentAlignment = Alignment.Center
    ) {
        if (group) Icon(Icons.Default.Group, null, tint = Color.White, modifier = Modifier.size((size * 0.55f).dp))
        else Text(name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#", color = Color.White,
            fontSize = (size * 0.42f).sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PermissionGate(onAsk: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Glass Messages needs access to your texts", fontSize = 20.sp, fontFamily = Heading, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAsk) { Text("Allow access") }
    }
}

/** Bold + blue matches, trimmed to a window around the first match. */
fun highlighted(text: String, q: String): AnnotatedString {
    val flat = text.replace('\n', ' ')
    var s = 0
    val first = flat.indexOf(q, ignoreCase = true)
    var t = flat
    if (first > 30) { s = first - 25; t = "…" + flat.substring(s) }
    return buildAnnotatedString {
        append(t)
        var i = t.indexOf(q, ignoreCase = true)
        while (i >= 0 && q.isNotEmpty()) {
            addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Accent), i, i + q.length)
            i = t.indexOf(q, i + q.length, ignoreCase = true)
        }
    }
}

@Composable private fun pageBg() = if (isSystemInDarkTheme()) Color.Black else Color(0xFFF2F2F7)
@Composable private fun cardBg() = if (isSystemInDarkTheme()) Color(0xFF1C1C1E) else Color.White

private fun cardShape(i: Int, n: Int): Shape {
    val r = 20.dp
    val top = if (i == 0) r else 0.dp
    val bottom = if (i == n - 1) r else 0.dp
    return RoundedCornerShape(topStart = top, topEnd = top, bottomStart = bottom, bottomEnd = bottom)
}

@Composable
private fun ThreadRow(
    t: ChatThread, snippet: AnnotatedString, date: Long, index: Int, count: Int,
    onClick: () -> Unit, onLong: () -> Unit = {}, pinned: Boolean = false
) {
    Column(Modifier.fillMaxWidth().clip(cardShape(index, count)).background(cardBg()).combinedClickable(onClick = onClick, onLongClick = onLong)) {
        Row(Modifier.padding(end = 14.dp, top = 11.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(22.dp), contentAlignment = Alignment.Center) {
                if (t.unread) Box(Modifier.size(10.dp).clip(CircleShape).background(Accent))
            }
            Avatar(t.name, 50, t.isGroup)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.name, fontWeight = if (t.unread) FontWeight.Bold else FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    if (pinned) Icon(Icons.Default.PushPin, "Pinned", tint = Color.Gray, modifier = Modifier.size(14.dp).padding(end = 2.dp))
                    Text(shortTime(date), fontSize = 13.sp, color = if (t.unread) Accent else Color.Gray)
                }
                Spacer(Modifier.height(2.dp))
                Text(snippet, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, lineHeight = 19.sp,
                    color = if (t.unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (index != count - 1) HorizontalDivider(Modifier.padding(start = 84.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
    }
}

@Composable
private fun SectionLabel(s: String) =
    Text(s, fontSize = 13.sp, fontFamily = Heading, fontWeight = FontWeight.Bold, color = Color.Gray,
        modifier = Modifier.padding(start = 8.dp, top = 16.dp, bottom = 6.dp))

@Composable
fun ConversationsScreen(
    repo: SmsRepo, showDefaultBanner: Boolean, onMakeDefault: () -> Unit,
    onOpen: (ChatThread, String?) -> Unit, onNew: () -> Unit
) {
    val ctx = LocalContext.current
    val threads by remember { repo.threadsFlow() }.collectAsState(emptyList())
    var query by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<ChatThread?>(null) }
    val drafts = remember { DraftStore(ctx) }
    val pinStore = remember { PinStore(ctx) }
    var pins by remember { mutableStateOf(pinStore.all()) }
    val ordered = remember(threads, pins) { threads.sortedByDescending { it.id in pins } }
    val q = query.trim()
    val hits by produceState(emptyList<SearchHit>(), q) {
        value = if (q.length < 2) emptyList() else { delay(250); withContext(Dispatchers.IO) { repo.search(q) } }
    }
    val byId = remember(threads) { threads.associateBy { it.id } }
    val matched = remember(threads, q) {
        if (q.isEmpty()) emptyList() else threads.filter { t ->
            t.name.contains(q, true) || t.addresses.any { addressMatches(it, q) }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().background(pageBg()).statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 8.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Messages", fontSize = 34.sp, fontFamily = Heading, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, modifier = Modifier.weight(1f))
                Box(Modifier.size(42.dp).clip(CircleShape).background(cardBg()).clickable(onClick = onNew), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Edit, "New message", tint = Accent, modifier = Modifier.size(20.dp))
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(cardBg())
                    .padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search", color = Color.Gray, fontSize = 16.sp)
                    BasicTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                        textStyle = TextStyle(fontFamily = Body, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                        cursorBrush = SolidColor(Accent))
                }
                if (query.isNotEmpty()) Icon(Icons.Default.Close, "Clear", tint = Color.Gray,
                    modifier = Modifier.size(20.dp).clickable { query = "" })
            }
        }
        if (showDefaultBanner && q.isEmpty()) item {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(Accent.copy(alpha = 0.12f))
                    .clickable(onClick = onMakeDefault).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Sms, null, tint = Accent)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Make Glass Messages your default app", fontWeight = FontWeight.SemiBold, color = Accent, fontSize = 15.sp)
                    Text("Needed to send photos, group texts and to delete", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
        if (q.isEmpty()) {
            if (threads.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Sms, null, tint = Color.Gray.copy(alpha = 0.5f), modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No conversations yet", color = Color.Gray, fontSize = 16.sp)
                    Text("Tap the pencil to start one", color = Color.Gray.copy(alpha = 0.7f), fontSize = 13.sp)
                }
            }
            itemsIndexed(ordered, key = { _, t -> t.id }) { i, t ->
                val d = drafts.get(t.id)
                val snip = if (d.isNotBlank()) buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.Red)) { append("Draft: ") }; append(d.flat())
                } else AnnotatedString(t.snippet)
                Box(Modifier.animateItem()) {
                    ThreadRow(t, snip, t.date, i, ordered.size, { onOpen(t, null) }, { menuFor = t }, t.id in pins)
                }
            }
        } else {
            if (matched.isNotEmpty()) {
                item { SectionLabel("Conversations") }
                itemsIndexed(matched, key = { _, t -> "c${t.id}" }) { i, t ->
                    ThreadRow(t, AnnotatedString(t.snippet), t.date, i, matched.size, { onOpen(t, null) })
                }
            }
            if (hits.isNotEmpty()) {
                item { SectionLabel("Messages") }
                itemsIndexed(hits, key = { _, h -> h.key }) { i, h ->
                    val t = byId[h.threadId] ?: ChatThread(h.threadId, listOf("Conversation"), "Conversation", "", h.date)
                    ThreadRow(t, highlighted(h.text, q), h.date, i, hits.size, { onOpen(t, h.key) })
                }
            }
            if (matched.isEmpty() && hits.isEmpty()) item {
                Text("No results", color = Color.Gray, modifier = Modifier.fillMaxWidth().padding(32.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }

    menuFor?.let { t ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton(onClick = { pinStore.toggle(t.id); pins = pinStore.all(); menuFor = null }) { Text(if (t.id in pins) "Unpin" else "Pin") }
                    if (t.unread) TextButton(onClick = { repo.markRead(t.id); menuFor = null }) { Text("Mark as read") }
                    if (!t.isGroup) TextButton(onClick = {
                        if (!repo.editContact(t.addresses[0])) Toast.makeText(ctx, "No contacts app found", Toast.LENGTH_SHORT).show()
                        menuFor = null
                    }) { Text("Edit contact") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!repo.deleteThread(t.id)) Toast.makeText(ctx,
                        if (repo.isDefault()) "Couldn't delete the conversation" else "Make Glass Messages your default SMS app to delete", Toast.LENGTH_SHORT).show()
                    menuFor = null
                }) { Text("Delete conversation", color = Color.Red) }
            },
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun NewMessageScreen(repo: SmsRepo, onCancel: () -> Unit, onStart: (List<String>) -> Unit) {
    val recipients = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    val suggestions by produceState(emptyList<Pair<String, String>>(), input) {
        value = if (input.isBlank()) emptyList() else withContext(Dispatchers.IO) { repo.searchContacts(input.trim()) }
    }
    val typed = input.trim()
    val looksNumber = typed.isNotEmpty() && typed.all { it.isDigit() || it in "+-() ." }
    fun add(name: String, num: String) { if (recipients.none { it.second == num }) recipients.add(name to num); input = "" }

    Column(Modifier.fillMaxSize().background(pageBg()).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onCancel) { Text("Cancel", color = Accent) }
            Text("New Message", fontFamily = Heading, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            TextButton(enabled = recipients.isNotEmpty() || looksNumber, onClick = {
                val l = recipients.map { it.second }.toMutableList()
                if (looksNumber) l.add(typed)
                onStart(l)
            }) { Text("Chat") }
        }
        HorizontalDivider(thickness = 0.5.dp)
        FlowRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("To:", color = Color.Gray)
            recipients.forEach { r ->
                Row(Modifier.clip(RoundedCornerShape(50)).background(Accent.copy(alpha = 0.15f)).clickable { recipients.remove(r) }
                    .padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(r.first, color = Accent, fontSize = 15.sp)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.Close, "Remove", tint = Accent, modifier = Modifier.size(14.dp))
                }
            }
            BasicTextField(input, { input = it }, Modifier.widthIn(min = 120.dp), singleLine = true,
                textStyle = TextStyle(fontFamily = Body, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp), cursorBrush = SolidColor(Accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (typed.isNotEmpty()) add(typed, typed) }))
        }
        HorizontalDivider(thickness = 0.5.dp)
        LazyColumn(Modifier.weight(1f)) {
            if (looksNumber) item {
                Text("Send to $typed", color = Accent, modifier = Modifier.fillMaxWidth().clickable { add(typed, typed) }.padding(16.dp))
            }
            items(suggestions, key = { it.second }) { (name, num) ->
                Column(Modifier.fillMaxWidth().clickable { add(name, num) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(num, fontSize = 13.sp, color = Color.Gray)
                }
            }
        }
    }
}
