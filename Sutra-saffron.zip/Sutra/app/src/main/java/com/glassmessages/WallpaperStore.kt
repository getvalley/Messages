package com.glassmessages

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import java.io.File

data class Wallpaper(val preset: String? = null, val imagePath: String? = null, val dim: Float = 0f)

class Preset(val id: String, val name: String, val colors: List<Color>)

val Presets = listOf(
    Preset("sunset", "Sunset", listOf(Color(0xFF8FA6B8), Color(0xFFF2B48C), Color(0xFFF7E3A1))),
    Preset("ocean", "Ocean", listOf(Color(0xFF0F2027), Color(0xFF2C5364), Color(0xFF4CA1AF))),
    Preset("aurora", "Aurora", listOf(Color(0xFF0B132B), Color(0xFF1C7C7D), Color(0xFF7BE0AD))),
    Preset("rose", "Rose", listOf(Color(0xFFFFC3D0), Color(0xFFFF8FB1), Color(0xFFB784F5))),
    Preset("mint", "Mint", listOf(Color(0xFFD4FC79), Color(0xFF96E6A1), Color(0xFF3DB8A5))),
    Preset("graphite", "Graphite", listOf(Color(0xFF232526), Color(0xFF414345), Color(0xFF616567))),
)

/** Stores one default wallpaper ("all") plus optional per-chat overrides ("t<threadId>"). */
class WallpaperStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("wallpapers", Context.MODE_PRIVATE)
    private var tick by mutableIntStateOf(0)

    fun keyFor(threadId: Long) = "t$threadId"
    fun hasOverride(threadId: Long): Boolean { tick; return prefs.contains("${keyFor(threadId)}.set") }

    fun get(threadId: Long): Wallpaper {
        tick
        val k = if (prefs.contains("${keyFor(threadId)}.set")) keyFor(threadId) else "all"
        return Wallpaper(prefs.getString("$k.preset", null), prefs.getString("$k.img", null), prefs.getFloat("$k.dim", 0f))
    }

    private fun edit(key: String, block: android.content.SharedPreferences.Editor.() -> Unit) {
        prefs.edit().apply { putBoolean("$key.set", true); block() }.apply()
        tick++
    }

    fun setPreset(key: String, id: String) {
        deleteImage(key)
        edit(key) { putString("$key.preset", id); remove("$key.img") }
    }

    fun setImage(key: String, uri: Uri) {
        val f = File(ctx.filesDir, "wp_${key}_${System.currentTimeMillis()}.jpg")
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        deleteImage(key)
        edit(key) { putString("$key.img", f.absolutePath); remove("$key.preset") }
    }

    fun setDim(key: String, dim: Float) = edit(key) { putFloat("$key.dim", dim) }

    fun reset(key: String) {
        deleteImage(key)
        prefs.edit().apply { prefs.all.keys.filter { it.startsWith("$key.") }.forEach { remove(it) } }.apply()
        tick++
    }

    private fun deleteImage(key: String) {
        prefs.getString("$key.img", null)?.let { File(it).delete() }
    }
}
