package com.glassmessages

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Launch(val threadId: Long?, val addresses: List<String>, val text: String?)
data class OpenChat(val thread: ChatThread, val focusKey: String? = null, val draft: String = "")

class MainActivity : ComponentActivity() {
    private var launch by mutableStateOf<Launch?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        launch = parse(intent)
        val repo = SmsRepo(applicationContext)
        val wp = WallpaperStore(applicationContext)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(), typography = AppTypography) {
                // Surface provides the content colour; without it Text defaults to black, unreadable in dark mode
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) {
                    App(repo, wp, launch) { launch = null }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launch = parse(intent)
    }

    override fun onResume() { super.onResume(); AppState.foreground = true; AppState.resumeTick.intValue++ }
    override fun onPause() { AppState.foreground = false; super.onPause() }

    private fun parse(i: Intent?): Launch? {
        i ?: return null
        val tid = i.getLongExtra("thread", -1L)
        val addrs = i.getStringArrayListExtra("addrs")
        if (tid != -1L && addrs != null) return Launch(tid, addrs, null)
        val d = i.data ?: return null
        if (d.scheme?.let { it in setOf("sms", "smsto", "mms", "mmsto") } != true) return null
        val list = android.net.Uri.decode(d.schemeSpecificPart).substringBefore('?').split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
        if (list.isEmpty()) return null
        return Launch(null, list, i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT))
    }
}

private val perms = arrayOf(
    Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
    Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_PHONE_NUMBERS
)

@Composable
fun App(repo: SmsRepo, wp: WallpaperStore, launch: Launch?, onLaunchConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember {
        mutableStateOf(ctx.checkSelfPermission(Manifest.permission.READ_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = it[Manifest.permission.READ_SMS] == true
    }
    var isDefault by remember { mutableStateOf(repo.isDefault()) }
    var roleTick by remember { mutableIntStateOf(0) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { roleTick++ }
    // Re-check whenever the app comes back to the foreground (the default can be changed in system settings)
    // and for a moment after the role dialog closes (the system can take a beat to commit the change).
    val resumes = AppState.resumeTick.intValue
    LaunchedEffect(resumes, roleTick) {
        isDefault = repo.isDefault()
        if (roleTick > 0 && !isDefault) repeat(6) { delay(500); isDefault = repo.isDefault(); if (isDefault) return@LaunchedEffect }
    }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(perms) }

    var open by remember { mutableStateOf<OpenChat?>(null) }
    var composing by remember { mutableStateOf(false) }
    BackHandler(open != null || composing) { if (open != null) open = null else composing = false }

    LaunchedEffect(launch, granted) {
        val l = launch ?: return@LaunchedEffect
        if (!granted) return@LaunchedEffect
        val (tid, name) = withContext(Dispatchers.IO) {
            (l.threadId ?: repo.threadIdFor(l.addresses)) to l.addresses.joinToString(", ") { repo.nameFor(it) }
        }
        open = OpenChat(ChatThread(tid, l.addresses, name, "", 0), null, l.text ?: "")
        composing = false
        onLaunchConsumed()
    }

    if (!granted) {
        PermissionGate { permLauncher.launch(perms) }
        return
    }
    val oc = open
    when {
        composing -> NewMessageScreen(repo, { composing = false }) { addrs ->
            scope.launch {
                val (tid, name) = withContext(Dispatchers.IO) { repo.threadIdFor(addrs) to addrs.joinToString(", ") { repo.nameFor(it) } }
                open = OpenChat(ChatThread(tid, addrs, name, "", 0))
                composing = false
            }
        }
        oc == null -> ConversationsScreen(
            repo = repo,
            showDefaultBanner = !isDefault,
            onMakeDefault = {
                val i = if (Build.VERSION.SDK_INT >= 29)
                    ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
                else
                    Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, ctx.packageName)
                try { roleLauncher.launch(i) } catch (_: Exception) { }
            },
            onOpen = { t, key -> open = OpenChat(t, key) },
            onNew = { composing = true }
        )
        else -> key(oc.thread.id) { ChatScreen(oc.thread, repo, wp, oc.focusKey, oc.draft) { open = null } }
    }
}
