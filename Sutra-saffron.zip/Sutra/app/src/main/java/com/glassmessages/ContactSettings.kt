package com.glassmessages

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFFF453A)

@Composable
private fun PersonAction(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = 0.12f)).clickable(onClick = onClick).padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = tint, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, label: String, destructive: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (destructive) Red else Accent, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = if (destructive) Red else MaterialTheme.colorScheme.onSurface, fontSize = 16.sp)
    }
}

/**
 * Everything about this chat's contact(s) in one page: call, edit or add, block, the chat wallpaper, and archive.
 * Drawn over the chat; Back returns to it.
 */
@Composable
fun ContactSettingsPage(
    thread: ChatThread, title: String, repo: SmsRepo, wp: WallpaperStore,
    onEdit: (String) -> Unit, onLeaveChat: () -> Unit, onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    val blocks = remember { BlockStore(ctx) }
    val archive = remember { ArchiveStore(ctx) }
    val contactsTick = AppState.contactsTick.intValue
    var confirmBlock by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(pageBg()).blockTouches().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Box(Modifier.align(Alignment.CenterStart).size(40.dp).clip(CircleShape).background(cardBg()).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.ArrowBackIosNew, "Back", tint = Accent, modifier = Modifier.size(18.dp))
            }
            Text(if (thread.isGroup) "Group" else "Contact", Modifier.align(Alignment.Center), fontFamily = Heading, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(title, 88, thread.isGroup)
                Spacer(Modifier.height(10.dp))
                Text(title, fontSize = 22.sp, fontFamily = Heading, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }

            SectionLabel(if (thread.isGroup) "People" else "Contact")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cardBg())) {
                thread.addresses.forEachIndexed { i, a ->
                    val saved = remember(a, contactsTick) { repo.contactUri(a) != null }
                    val name = remember(a, contactsTick) { repo.nameFor(a) }
                    val blocked = blocks.isBlocked(a)
                    if (i > 0) HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(name, 44)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (name != a) Text(a, fontSize = 13.sp, color = Color.Gray)
                            }
                            if (blocked) Text("Blocked", fontSize = 12.sp, color = Red, fontWeight = FontWeight.Medium)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PersonAction(Icons.Default.Call, "Call", Accent, Modifier.weight(1f)) {
                                if (!repo.dial(a)) Toast.makeText(ctx, "Can't open dialer", Toast.LENGTH_SHORT).show()
                            }
                            PersonAction(if (saved) Icons.Default.Edit else Icons.Default.PersonAdd, if (saved) "Edit" else "Add", Accent, Modifier.weight(1f)) { onEdit(a) }
                            if (blocked) PersonAction(Icons.Default.CheckCircle, "Unblock", Accent, Modifier.weight(1f)) {
                                blocks.unblock(a)
                                Toast.makeText(ctx, "Unblocked $name", Toast.LENGTH_SHORT).show()
                            } else PersonAction(Icons.Default.Block, "Block", Red, Modifier.weight(1f)) { confirmBlock = a }
                        }
                    }
                }
            }

            SectionLabel("Wallpaper")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cardBg()).padding(16.dp)) {
                WallpaperSection(thread.id, wp)
            }

            SectionLabel("Conversation")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cardBg())) {
                SettingsRow(Icons.Default.Archive, "Archive conversation") {
                    archive.archive(thread.id, repo.threadDate(thread.id))
                    Toast.makeText(ctx, "Conversation archived", Toast.LENGTH_SHORT).show()
                    onLeaveChat()
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    confirmBlock?.let { a ->
        val name = repo.nameFor(a)
        AlertDialog(
            onDismissRequest = { confirmBlock = null },
            title = { Text("Block $name?") },
            text = {
                Text("Messages from this number will no longer arrive or notify you in Sutra, and this chat moves to Blocked." +
                    if (repo.isDefault()) "" else "\n\nSutra needs to be your default SMS app for blocking to take effect.")
            },
            confirmButton = {
                TextButton(onClick = {
                    blocks.block(a); confirmBlock = null
                    Toast.makeText(ctx, "Blocked $name", Toast.LENGTH_SHORT).show()
                    if (!thread.isGroup) onLeaveChat()   // a blocked 1:1 chat leaves the main list, so leave the chat too
                }) { Text("Block", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmBlock = null }) { Text("Cancel") } }
        )
    }
}

/** Wallpaper picker used inside the contact settings page. */
@Composable
fun WallpaperSection(threadId: Long, wp: WallpaperStore) {
    var forAll by remember { mutableStateOf(!wp.hasOverride(threadId)) }
    val key = if (forAll) "all" else wp.keyFor(threadId)
    val current = wp.get(threadId)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) wp.setImage(key, uri)
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Use for all chats", Modifier.weight(1f))
        Switch(forAll, { forAll = it })
    }
    Spacer(Modifier.height(12.dp))
    Presets.chunked(3).forEach { rowItems ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            rowItems.forEach { p ->
                Box(
                    Modifier.weight(1f).aspectRatio(0.8f).clip(RoundedCornerShape(14.dp))
                        .background(Brush.verticalGradient(p.colors))
                        .border(if (current.preset == p.id) 3.dp else 0.dp, Accent, RoundedCornerShape(14.dp))
                        .clickable { wp.setPreset(key, p.id) },
                    contentAlignment = Alignment.BottomCenter
                ) { Text(p.name, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(6.dp)) }
            }
            repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
        }
        Spacer(Modifier.height(10.dp))
    }
    Spacer(Modifier.height(4.dp))
    Text("Dim", fontSize = 14.sp, color = Color.Gray)
    Slider(current.dim, { wp.setDim(key, it) }, valueRange = 0f..0.7f)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Choose photo") }
        OutlinedButton(onClick = { wp.reset(key) }) { Text("Reset") }
    }
}
