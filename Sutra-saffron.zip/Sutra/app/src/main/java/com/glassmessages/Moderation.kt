package com.glassmessages

import android.content.Context
import android.telephony.PhoneNumberUtils
import androidx.compose.runtime.mutableIntStateOf

internal fun sameAddress(a: String, b: String): Boolean =
    a.equals(b, ignoreCase = true) || try { PhoneNumberUtils.compare(a, b) } catch (_: Exception) { false }

/**
 * Numbers you have blocked. Messages from them are dropped as they arrive (nothing is saved, nothing notifies),
 * and their existing chat moves out of the main list into Blocked. Needs Sutra to be the default SMS app to take effect,
 * because only the default app receives incoming messages.
 */
class BlockStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("blocks", Context.MODE_PRIVATE)

    companion object {
        /** Read inside composables so screens refresh when the list changes. */
        val tick = mutableIntStateOf(0)
    }

    fun all(): List<String> {
        tick.intValue
        return (p.getStringSet("numbers", emptySet()) ?: emptySet()).sorted()
    }

    fun isBlocked(address: String): Boolean = all().any { sameAddress(it, address) }

    fun block(address: String) {
        val a = address.trim()
        if (a.isEmpty() || isBlocked(a)) return
        val s = HashSet(p.getStringSet("numbers", emptySet()) ?: emptySet())
        s.add(a)
        p.edit().putStringSet("numbers", s).apply()
        tick.intValue++
    }

    fun unblock(address: String) {
        val s = HashSet(p.getStringSet("numbers", emptySet()) ?: emptySet())
        if (!s.removeAll { sameAddress(it, address) }) return
        p.edit().putStringSet("numbers", s).apply()
        tick.intValue++
    }
}

/**
 * Archived conversations. An archive entry remembers the conversation's last-activity time at the moment you archived it;
 * as soon as anything newer arrives (or you send something) the conversation comes back to the main list by itself.
 */
class ArchiveStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("archive", Context.MODE_PRIVATE)

    companion object {
        val tick = mutableIntStateOf(0)
    }

    fun isArchived(t: ChatThread): Boolean {
        tick.intValue
        val at = p.getLong(t.id.toString(), -1L)
        return at >= 0 && t.date <= at
    }

    fun archive(threadId: Long, lastActivity: Long) {
        p.edit().putLong(threadId.toString(), lastActivity).apply()
        tick.intValue++
    }

    fun unarchive(threadId: Long) {
        p.edit().remove(threadId.toString()).apply()
        tick.intValue++
    }
}

/** A 1:1 chat with a number you've blocked. These live in Blocked instead of the main list. */
fun BlockStore.blocksThread(t: ChatThread): Boolean = !t.isGroup && t.addresses.isNotEmpty() && isBlocked(t.addresses[0])
