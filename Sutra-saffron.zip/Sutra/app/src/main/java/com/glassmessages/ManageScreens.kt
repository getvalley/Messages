package com.glassmessages

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun PageHeader(title: String, onBack: () -> Unit, trailing: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 16.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(cardBg()).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ArrowBackIosNew, "Back", tint = Accent, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 30.sp, fontFamily = Heading, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, hint: String) {
    Column(Modifier.fillMaxWidth().padding(48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Color.Gray.copy(alpha = 0.5f), modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.Gray, fontSize = 16.sp, textAlign = TextAlign.Center)
        Text(hint, color = Color.Gray.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

/** Conversations you've archived. They return to Messages on their own when something new arrives. */
@Composable
fun ArchivedScreen(repo: SmsRepo, onBack: () -> Unit, onOpen: (ChatThread, String?) -> Unit) {
    val ctx = LocalContext.current
    val threads by remember { repo.threadsFlow() }.collectAsState(emptyList())
    val archive = remember { ArchiveStore(ctx) }
    val blocks = remember { BlockStore(ctx) }
    val list = threads.filter { archive.isArchived(it) && !blocks.blocksThread(it) }
    var menuFor by remember { mutableStateOf<ChatThread?>(null) }

    Column(Modifier.fillMaxSize().background(pageBg()).statusBarsPadding().navigationBarsPadding()) {
        PageHeader("Archived", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
            if (list.isEmpty()) item { EmptyState(Icons.Default.Archive, "No archived conversations", "Long-press a conversation and choose Archive") }
            itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                ThreadRow(t, AnnotatedString(t.snippet), t.date, i, list.size, { onOpen(t, null) }, { menuFor = t })
            }
        }
    }

    menuFor?.let { t ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                TextButton(onClick = { archive.unarchive(t.id); menuFor = null }) { Text("Unarchive") }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!repo.deleteThread(t.id)) Toast.makeText(ctx,
                        if (repo.isDefault()) "Couldn't delete the conversation" else "Make Sutra your default SMS app to delete", Toast.LENGTH_SHORT).show()
                    menuFor = null
                }) { Text("Delete conversation", color = Color.Red) }
            },
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Cancel") } }
        )
    }
}

/** Numbers you've blocked. Add one by hand, or unblock any of them. Tap a row to read the old conversation. */
@Composable
fun BlockedScreen(repo: SmsRepo, onBack: () -> Unit, onOpen: (ChatThread, String?) -> Unit) {
    val ctx = LocalContext.current
    val blocks = remember { BlockStore(ctx) }
    val threads by remember { repo.threadsFlow() }.collectAsState(emptyList())
    val numbers = blocks.all()
    var adding by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val contactsTick = AppState.contactsTick.intValue

    Column(Modifier.fillMaxSize().background(pageBg()).statusBarsPadding().navigationBarsPadding()) {
        PageHeader("Blocked", onBack) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(cardBg()).clickable { input = ""; adding = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, "Block a number", tint = Accent, modifier = Modifier.size(22.dp))
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
            item {
                Text("Texts from blocked numbers are dropped and never notify you. Your old conversation stays here until you delete it. Blocking only works while Sutra is your default SMS app.",
                    fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp))
            }
            if (numbers.isEmpty()) item { EmptyState(Icons.Default.Block, "No blocked numbers", "Tap + to block one, or block someone from their contact page") }
            itemsIndexed(numbers, key = { _, n -> n }) { i, n ->
                val thread = threads.firstOrNull { !it.isGroup && sameAddress(it.addresses[0], n) }
                val name = remember(n, contactsTick) { repo.nameFor(n) }
                val shape = when {
                    numbers.size == 1 -> androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
                    i == 0 -> androidx.compose.foundation.shape.RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                    i == numbers.lastIndex -> androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
                    else -> androidx.compose.foundation.shape.RoundedCornerShape(0.dp)
                }
                Row(
                    Modifier.fillMaxWidth().clip(shape).background(cardBg())
                        .then(if (thread != null) Modifier.clickable { onOpen(thread, null) } else Modifier)
                        .padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(name, 44)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (name != n) Text(n, fontSize = 13.sp, color = Color.Gray)
                    }
                    TextButton(onClick = {
                        blocks.unblock(n)
                        Toast.makeText(ctx, "Unblocked $name", Toast.LENGTH_SHORT).show()
                    }) { Text("Unblock", color = Accent) }
                }
                if (i != numbers.lastIndex) HorizontalDivider(Modifier.padding(start = 70.dp), thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
            }
        }
    }

    if (adding) AlertDialog(
        onDismissRequest = { adding = false },
        title = { Text("Block a number") },
        text = {
            OutlinedTextField(input, { input = it }, singleLine = true, label = { Text("Phone number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        },
        confirmButton = {
            TextButton(enabled = input.isNotBlank(), onClick = {
                blocks.block(input); adding = false
            }) { Text("Block", color = if (input.isNotBlank()) Color.Red else Color.Gray) }
        },
        dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
    )
}
