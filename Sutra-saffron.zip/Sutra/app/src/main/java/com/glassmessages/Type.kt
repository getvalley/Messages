package com.glassmessages

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Headings: Libre Baskerville Bold. */
val Heading = FontFamily(Font(R.font.libre_baskerville_bold, FontWeight.Bold))

/** Everything else: Bricolage Grotesque (static instances of the variable font, opsz 14, wdth 100). */
val Body = FontFamily(
    Font(R.font.bricolage_regular, FontWeight.Normal),
    Font(R.font.bricolage_medium, FontWeight.Medium),
    Font(R.font.bricolage_semibold, FontWeight.SemiBold),
    Font(R.font.bricolage_bold, FontWeight.Bold)
)

private fun TextStyle.heading() = copy(fontFamily = Heading, fontWeight = FontWeight.Bold)
private fun TextStyle.body() = copy(fontFamily = Body)
private fun TextStyle.bodyTight() = copy(fontFamily = Body, letterSpacing = 0.sp)

private val m3Defaults = Typography()

val AppTypography = Typography(
    displayLarge = m3Defaults.displayLarge.heading(),
    displayMedium = m3Defaults.displayMedium.heading(),
    displaySmall = m3Defaults.displaySmall.heading(),
    headlineLarge = m3Defaults.headlineLarge.heading(),
    headlineMedium = m3Defaults.headlineMedium.heading(),
    headlineSmall = m3Defaults.headlineSmall.heading(),
    titleLarge = m3Defaults.titleLarge.heading(),
    titleMedium = m3Defaults.titleMedium.body(),
    titleSmall = m3Defaults.titleSmall.body(),
    bodyLarge = m3Defaults.bodyLarge.bodyTight(),
    bodyMedium = m3Defaults.bodyMedium.bodyTight(),
    bodySmall = m3Defaults.bodySmall.body(),
    labelLarge = m3Defaults.labelLarge.body(),
    labelMedium = m3Defaults.labelMedium.body(),
    labelSmall = m3Defaults.labelSmall.body()
)
