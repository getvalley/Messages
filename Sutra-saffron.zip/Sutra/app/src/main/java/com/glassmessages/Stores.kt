package com.glassmessages

import android.content.Context

/** Unsent text per conversation. */
class DraftStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("drafts", Context.MODE_PRIVATE)
    fun get(threadId: Long): String = p.getString(threadId.toString(), "") ?: ""
    fun set(threadId: Long, text: String) {
        p.edit().apply { if (text.isBlank()) remove(threadId.toString()) else putString(threadId.toString(), text) }.apply()
    }
}

/** Conversations pinned to the top of the list. */
class PinStore(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("pins", Context.MODE_PRIVATE)
    fun all(): Set<Long> = (p.getStringSet("pins", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    fun toggle(threadId: Long) {
        val s = HashSet(p.getStringSet("pins", emptySet()) ?: emptySet())
        if (!s.remove(threadId.toString())) s.add(threadId.toString())
        p.edit().putStringSet("pins", s).apply()
    }
}
