package com.glassmessages

import android.app.*
import android.content.*
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import androidx.compose.runtime.mutableIntStateOf
import kotlinx.coroutines.runBlocking
import java.io.File
import kotlin.concurrent.thread

object AppState {
    @Volatile var foreground = false
    @Volatile var openThread = -1L
    /** Bumped every time the activity resumes, so screens can re-check state that may have changed outside the app. */
    val resumeTick = mutableIntStateOf(0)
    /** Bumped whenever contacts change, so names shown on screen re-read the address book. */
    val contactsTick = mutableIntStateOf(0)
}

object Notifier {
    private const val CH = "msgs"
    const val ACT_REPLY = "com.glassmessages.REPLY"
    const val ACT_READ = "com.glassmessages.MARK_READ"

    fun post(c: Context, repo: SmsRepo, threadId: Long, addrs: List<String>, text: String) {
        if (AppState.foreground && AppState.openThread == threadId) return
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Messages", NotificationManager.IMPORTANCE_HIGH))
        val id = threadId.toInt()
        val list = ArrayList(addrs)

        val open = PendingIntent.getActivity(c, id,
            Intent(c, MainActivity::class.java).putExtra("thread", threadId).putStringArrayListExtra("addrs", list)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        fun act(action: String) = Intent(c, NotifActionReceiver::class.java).setAction(action)
            .putExtra("thread", threadId).putStringArrayListExtra("addrs", list)

        val replyPi = PendingIntent.getBroadcast(c, id, act(ACT_REPLY), PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val readPi = PendingIntent.getBroadcast(c, id, act(ACT_READ), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val ri = RemoteInput.Builder("reply").setLabel("Reply").build()
        val reply = Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Reply", replyPi)
            .addRemoteInput(ri).build()
        val read = Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_view), "Mark as read", readPi).build()

        val n = Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(addrs.joinToString(", ") { repo.nameFor(it) })
            .setContentText(splitReply(text).second.ifBlank { text })
            .setStyle(Notification.BigTextStyle().bigText(splitReply(text).second.ifBlank { text }))
            .setContentIntent(open).setAutoCancel(true)
            .addAction(reply).addAction(read)
            .build()
        nm.notify(id, n)
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val addr = msgs.firstOrNull()?.originatingAddress ?: return
        if (BlockStore(c).isBlocked(addr)) return   // blocked number: drop silently
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val v = ContentValues().apply {
            put(Telephony.Sms.ADDRESS, addr)
            put(Telephony.Sms.BODY, body)
            put(Telephony.Sms.DATE, System.currentTimeMillis())
            put(Telephony.Sms.DATE_SENT, msgs.first().timestampMillis)
            put(Telephony.Sms.READ, 0)
            put("seen", 0)
        }
        c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
        SmsRepo.poke()
        val thread = Telephony.Threads.getOrCreateThreadId(c, addr)
        Notifier.post(c, SmsRepo(c), thread, listOf(addr), body)
    }
}

/** WAP push: an MMS is waiting at the carrier. Download it, then store + notify. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val data = i.getByteArrayExtra("data") ?: return
        val n = MmsCodec.parseNotification(data) ?: return
        if (n.from != null && BlockStore(c).isBlocked(n.from.substringBefore("/TYPE"))) return   // blocked sender: never download
        val repo = SmsRepo(c)
        if (!repo.claimMms(n.tid)) return
        try { repo.downloadMms(n) } catch (_: Exception) { repo.releaseMms(n.tid) }
    }
}

class MmsDownloadedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val path = i.getStringExtra("file"); val tid = i.getStringExtra("tid"); val from = i.getStringExtra("from")
        val ok = resultCode == Activity.RESULT_OK
        if (!ok) reportMmsError(c, "MMS download", resultCode, i)
        val pr = goAsync()
        thread {
            try {
                val f = path?.let { File(it) }
                val repo = SmsRepo(c)
                if (ok && f != null && f.length() > 0) {
                    val inc = repo.saveIncoming(f.readBytes(), from, tid)
                    if (inc != null) { SmsRepo.poke(); Notifier.post(c, repo, inc.threadId, inc.addresses, inc.preview) }
                    else tid?.let { repo.releaseMms(it) }
                } else tid?.let { SmsRepo(c).releaseMms(it) }
                f?.delete()
            } catch (_: Exception) {
            } finally { pr.finish() }
        }
    }
}

fun reportMmsError(c: Context, what: String, code: Int, i: Intent) {
    val http = i.getIntExtra("android.telephony.extra.MMS_HTTP_STATUS", 0)
    val msg = "$what failed (code $code, HTTP $http)"
    android.util.Log.e("GlassMessages", msg)
    android.os.Handler(android.os.Looper.getMainLooper()).post { android.widget.Toast.makeText(c, msg, android.widget.Toast.LENGTH_LONG).show() }
}

class MmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val uri = i.data ?: return
        if (resultCode != Activity.RESULT_OK) reportMmsError(c, "MMS send", resultCode, i)
        try {
            c.contentResolver.update(uri, ContentValues().apply { put("msg_box", if (resultCode == Activity.RESULT_OK) 2 else 5) }, null, null)
        } catch (_: Exception) { }
        i.getStringExtra("file")?.let { File(it).delete() }
        SmsRepo.poke()
    }
}

class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val uri = i.data ?: return
        val v = ContentValues()
        when (i.action) {
            SmsRepo.ACT_SMS_SENT ->
                if (resultCode == Activity.RESULT_OK) v.put("type", Telephony.Sms.MESSAGE_TYPE_SENT)
                else { v.put("type", Telephony.Sms.MESSAGE_TYPE_FAILED); v.put("error_code", resultCode) }
            SmsRepo.ACT_SMS_DELIVERED -> {
                val pdu = i.getByteArrayExtra("pdu") ?: return
                val st = try { android.telephony.SmsMessage.createFromPdu(pdu, i.getStringExtra("format")).status } catch (_: Exception) { return }
                v.put("status", st)
            }
            else -> return
        }
        try { c.contentResolver.update(uri, v, null, null) } catch (_: Exception) { }
        SmsRepo.poke()
    }
}

class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val tid = i.getLongExtra("thread", -1L)
        val addrs = i.getStringArrayListExtra("addrs") ?: return
        val nm = c.getSystemService(NotificationManager::class.java)
        val repo = SmsRepo(c)
        when (i.action) {
            Notifier.ACT_READ -> { repo.markRead(tid); nm.cancel(tid.toInt()) }
            Notifier.ACT_REPLY -> {
                val txt = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString()?.trim()
                if (txt.isNullOrEmpty()) return
                val pr = goAsync()
                thread {
                    try { runBlocking { repo.send(addrs, txt, emptyList()) }; repo.markRead(tid) }
                    finally { nm.cancel(tid.toInt()); pr.finish() }
                }
            }
        }
    }
}

/** "Respond via message" from the in-call screen. */
class RespondService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val text = i?.getStringExtra(Intent.EXTRA_TEXT)
        val to = i?.data?.schemeSpecificPart?.substringBefore('?')?.split(',', ';')?.map { it.trim() }?.filter { it.isNotEmpty() }
        if (!text.isNullOrBlank() && !to.isNullOrEmpty()) {
            thread { try { runBlocking { SmsRepo(applicationContext).send(to, text, emptyList()) } } finally { stopSelf(startId) } }
        } else stopSelf(startId)
        return START_NOT_STICKY
    }
}
