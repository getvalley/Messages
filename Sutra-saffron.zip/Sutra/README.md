# Sutra
iMessage-style SMS/MMS app for Android (Kotlin, Jetpack Compose).

1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a real phone with a SIM. Emulators cannot send real SMS/MMS.
3. Grant the permissions, then tap the banner to make it your default SMS app.
   Sending MMS/group texts, receiving MMS, deleting and mark-as-read all require being the default app.

## Features
- SMS + MMS: send/receive photos, videos, audio, subject lines (own PDU codec in Mms.kt, no extra library)
- Group chats (group MMS), sender names in groups
- Search: global (conversations + message text, SMS and MMS) and in-conversation with next/previous
- Unread dots, auto mark-as-read, notifications with Reply and Mark as read
- Delivery status under the last sent message (Sending / Sent / Delivered / Not Delivered)
- New message screen with contact suggestions, multiple recipients
- Long-press message: copy, resend (failed SMS), delete. Long-press conversation: delete, mark read
- Contacts: tap the avatar in a chat (or long-press a conversation) to edit or add the contact
- Tappable links, fullscreen image viewer with share, open other attachments externally
- Emoji reactions (long-press a message or photo) and replies with a quoted preview; both travel as plain text so they work over SMS/MMS (see Notes)
- Phone number search ignores spaces, dashes and country code ("98765" finds +91 98765 43200)
- Swipe a message right to reply, drafts are kept per chat (shown in red in the list), pin chats from the long-press menu
- sms:/smsto: links, "respond via message", per-chat wallpapers

## Notes
- True read receipts do not exist on SMS/MMS, so delivery status is shown instead.
- MMS is the least forgiving part: it depends on your carrier's MMSC. Attachments are compressed to about 1 MB.
  If downloads fail on a specific phone, check Logcat for the MmsDownloadedReceiver result code.
- Reactions are sent as a text like `Reacted 😂 to “hello”` (Google Messages format; iMessage-style "Loved “…”" is also understood). Messages that look like that are folded into a badge on the original message. Replies are sent as `↪ “quoted text”` + a new line + your text, so the other side still sees the context in any SMS app. Emoji make a text use Unicode, so one SMS part holds 70 characters instead of 160.
- Not included: RCS, per-message resend for MMS.

## Fonts
- Headings (screen titles, section labels, sheet and dialog titles): Libre Baskerville Bold.
- Everything else: Bricolage Grotesque (static Regular/Medium/SemiBold/Bold cut from the variable font at opsz 14).
- Both are licensed under the SIL Open Font License. Definitions live in `Type.kt`; font files are in `app/src/main/res/font/`.
